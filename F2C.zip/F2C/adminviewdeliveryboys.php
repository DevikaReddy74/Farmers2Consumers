<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">

    <div class="col-12">
      <h1 class="center white"><u>Delivery Boys Details</u></h1>
      <div class='card' style='width: auto;'>
	  		<div class='card-body'>
        <br/>
      <table border="1" align="center">
         <tr class="center">
           <th>&nbsp;S.No&nbsp;</th>
           <th>Assigned To</th>
           <th>&nbsp;Name&nbsp;</th>
           <th>Image</th>
           <th>&nbsp;Gender&nbsp;</th>
           <th>DOB</th>
           <th>Phone No</th>
           <th>Email</th>
           <th>Address</th>
           <th>&nbsp;Assigned Orders&nbsp;</th>
           <th>Delete</th>
         </tr>
<?php
 $conn=new mysqli("localhost","root","","f2c");
 $sql="SELECT `deliveryBoyId`, `fullName`, `image`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `assignedTo`, `registerDate`, `updateOn` FROM `deliveryboy` ORDER BY `assignedTo`";
 $stmt=$conn->prepare($sql);
 $stmt->execute();
 $stmt->bind_result($delboyid,$fname,$img,$gen,$dob,$phone,$mail,$addr,$asgnto,$regdate,$update);
 $a=0;
 $i=1;
 while($stmt->fetch())
 {
  $a=1;
  echo "  <tr>
          <td>&nbsp;".$i."</td>
          <td>&nbsp;".$asgnto."</td>
          <td>&nbsp;".$fname."&nbsp;</td>
          <td><img src='".$img."' height='50%' width='80' alt='image'/></td>
          <td>&nbsp;".$gen."&nbsp;</td>
          <td>&nbsp;".$dob."&nbsp;</td>
          <td>&nbsp;".$phone."&nbsp;</td>
          <td>&nbsp;".$mail."&nbsp;</td>
          <td>".$addr."</td>
          <td><center><a href='adminviewdelboyasignedpro.php?dbid=$delboyid'>
            <button type='button' class='btn btn-dark'>View</button>
          </a></center></td>
          <td><center>&nbsp;<a href='adminviewdeliveryboy.php?dbid=$delboyid'>
            <button type='button' class='btn btn-dark'>Delete</button>
          </a>&nbsp;</center></td>
         </tr>";
  $i++;
 }
 if($a==0)
 {
  echo " <tr>
          <td colspan='8'>
            <h1 align='center'>Empty!<h1/>
          </td>
         </tr>";
 }
 if(!empty($_GET['dbid']))
 {
  $delboy=$_GET['dbid'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `deliveryboy` WHERE `deliveryBoyId` = ? ");
  $stmt->bind_param("s",$delboy);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
   echo "
    <script>
      window.alert(' Deleted successfully');
    </script>";
  }
  else
  {
   echo "<script>window.alert('Not Deleted');</script>";
  }
 }
?>
      </table>
      <br/>
    </div>

  </div>
  <br/>
  <br/>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>