<?php
session_start();
if(!empty($_SESSION['farmer']))
{
	unset($_SESSION['farmer']);
    header('Location: farmerlogin.php');
}
else
{
    header('Location: farmerlogin.php');
}
?>