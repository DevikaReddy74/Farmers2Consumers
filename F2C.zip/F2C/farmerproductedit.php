<?php
session_start();
if(!empty($_SESSION['farmer']))
{
  $pro=$_GET['proid'];
  $id=$_GET['edit'];
	require_once('backgroundhead.php');
  require_once('farmermenubar.php');

?>
<div class="alert">
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4">
<?php

  if($id=="img")
 {
?>
      <div class="card" style="width: auto;">
        <h1 class="center"><u>Product Image</u></h1><br/>
        <form action="" method="post" align="center" enctype="multipart/form-data" >
          <table border="0" align="center">
            <tr>
              <td>Image</td>
              <td>
                <input type="file" name="pfile" required/>
              </td>
            </tr>
            <tr>
              <td colspan="2"><br/></td>
            </tr>
            <tr>
              <td>
                <a href="farmerhome.php">
                  <button type="button" class='btn btn-dark'>Back</button>
                </a>
              </td>
              <td>
                <button type="submit" name="apies" class='btn btn-dark'>Update</button>
              </td>
            </tr>
          </table>
        </form>
        <br/>
      </div>

<?php
    if(isset($_POST['apies']))
    {
	    $fname=$_FILES['pfile']['name'];
	    $ftemp=$_FILES['pfile']['tmp_name'];//default storage of images
	    $ferr=$_FILES['pfile']['error'];
	    if($ferr==0)
	    {
	  	  date_default_timezone_set("Asia/Calcutta");//timezone
        $fname=date('dmYHis',time());// date and time
		    $fdest="./images/".$fname;
		    move_uploaded_file($ftemp,$fdest);//source, destination
    
        $conn=new mysqli("localhost","root","","f2c");
        $sql="UPDATE `product` SET `image`=? WHERE `productId`=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param("ss",$fdest,$pro);
        $stmt->execute();
        if($stmt->affected_rows==1)
        {
		      echo "<script>window.alert('Updated successfully');</script>";
        }
        else
        {
		      echo "<script>window.alert('Not Updated');</script>";
        }
      }
	    else
	    {
		    echo "<script>window.alert('Error while uploading the file');</script>";
	    }
    }  
  }



  if($id=="data")
  {
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="SELECT `productName`, `image`, `price`, `quantity`, `description` FROM `product` WHERE `productId`=?";
    $stmt1=$conn->prepare($sql1); 
    $stmt1->bind_param("s",$pro);  
    $stmt1->execute();
    $stmt1->bind_result($name,$image,$price,$quant,$des);
    $a=0;
    while($stmt1->fetch())
    {
			$a=1;
    }
    if($a==1)
    {													
      echo ' 
			<div class="card" style="width: auto;">
        <div class="card-body">
					<form action="" method="post" align="center" enctype="multipart/form-data">
            <table align="center">
              <tr>
                <td colspan="2">
                  <u><h1>Product Edit </h1></u>
                </td>
              </tr>
              <tr>
                <td colspan="2"><br/></td>
              </tr>
              <tr>
                <td>Product Name</td>
                <td>
                  <input type="text" name="pname" maxlength="15" value="'.$name.'" required/>
                </td>
              </tr>
              <tr>
                <td>Price ₹ /KG</td>
                <td>
                  <input type="text" name="pprice" maxlength="4" value="'.$price.'" required/>
                </td>
              </tr>
              <tr>
                <td>Available Quantity in KGs</td>
                <td>
                  <input type="text" name="pquant" maxlength="4" value="'.$quant.'" required/>
                </td>
              </tr>
              <tr>
                <td>Description</td>
                <td>
                  <input type="text" name="pdes" maxlength="30" value="'.$des.'" required/>
                </td>
              </tr>
              <tr>
                <td>Available</td>
                <td>
                  <select name="avail">
                    <option>yes</option>
                    <option>no</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td><br/></td>
              </tr>
              <tr>
                <td>
                  <a href="farmerhome.php">
                    <button type="button" class="btn btn-dark">Back</button>
                  </a>
                </td>
                <td>
                  <button type="submit" name="fpes" class="btn btn-dark">Update</button>
                </td>
              </tr>
            </table>
          </form>
        </div>
      </div>	 ';
    }
    else
    {
			echo "<h2>There Is No Such Type Of Product To Update</h2>";
    }

  }

  if(isset($_POST['fpes']))
  {
    date_default_timezone_set("Asia/Calcutta");//timezone
    $date=date('d-m-Y H:i:s',time());// date and time

		$name=$_POST['pname'];
    $price=$_POST['pprice'];
    $quant=$_POST['pquant'];
    $des=$_POST['pdes'];
    $avail=$_POST['avail'];
    $conn=new mysqli("localhost","root","","f2c");
    $sql2="UPDATE `product` SET `productName`=?,`price`=?,`quantity`=?,`description`=?,`available`=?,`updateOn`=? WHERE `productId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("sssssss",$name,$price,$quant,$des,$avail,$date,$pro);
    $stmt2->execute();
    if($stmt2->affected_rows==1)
    {
			echo "<script>window.alert('Item Updated successfully');</script>";
		}
    else
    {
		  echo "<script>window.alert('Item is not Updated');</script>";
    }
    if($quant==0 || $avail=="no"){
      $sql3="DELETE FROM `cart` WHERE `productId`=?";
      $stmt3=$conn->prepare($sql3);
      $stmt3->bind_param("s",$pro);
      $stmt3->execute();
      if($stmt3->affected_rows>0)
      {
      }
    }
  }
?>
    </div>
    <div class="col-4">
    </div>
  </div>
</div>
<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: farmerlogin.php');
}
?>
