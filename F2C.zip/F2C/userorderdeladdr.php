<?php
session_start();
if(!empty($_SESSION['user']))
{
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4">
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <h1 class="center"><u>Delivery Address</u></h1><br/>
<?php
  if(!empty($_GET['deladdr'])){
    echo "<center>".$_GET['deladdr']."<br/><br/><a href='userorders.php'>
            <button type='button' class='btn btn-dark'>Back</button>
                    </a></center>";

  }
  else{

  $userid=$_SESSION['user'];
  $orderid=$_GET['oid'];
  if(!empty($orderid))
  {

?>


          <form action="" method="post">
            <table align="center">
              <tr>
                <td>Name</td>
                <td>: <input type="text" name="name" required/></td>
              </tr>
              <tr>
                <td>C/O</td>
                <td>: <input type="text" name="co" required/></td>
              </tr>
              <tr>
                <td>Door No.</td>
                <td>: <input type="text" name="dno" required/></td>
              </tr>
              <tr>
                <td>Address Line</td>
                <td>: <input type="text" name="addr" required></td>
              </tr>
              <tr>
                <td>Mandal</td>
                <td> :
                  <select name="mandal">
                    <?php require_once('mandals.php'); ?>
                  </select> 
                </td>
              </tr>
              <tr>
                <td>District</td>
                <td> :
                  <select name="dist">
                    <option>Anantapur</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td>Pincode</td>
                <td>: <input type="text" name="pincode" maxlength="6" required></td>
              </tr>
              <tr>
                <td>Phone No</td>
                <td>: <input type="text" name="ph" maxlength="10" required></td>
              </tr>
              <tr>
                <td class="center"><a href="userorders.php">
                  <button type="button" name="sub" class="btn btn-dark">Back</button></a>
                </td>
                <td class="center">
                  <button type="submit" name="sub" class="btn btn-dark">Submit</button>
                </td>
              </tr>
            </table>           
          </form>
          <br/>


<?php

    if(isset($_POST['sub']))
    {
      $addr=$_POST['name'].", C/O ".$_POST['co']."<br/>".$_POST['dno'].", ".$_POST['addr'].", ".$_POST['mandal'].", ".$_POST['dist']."<br/>".$_POST['pincode'].", ".$_POST['ph'];
      
      $mandal=$_POST['mandal'];
      $ottl=0;
      $conn=new mysqli("localhost","root","","f2c");
      $sql="SELECT `orderTotal` FROM `orders` WHERE `orderId`=?";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("s",$orderid);
      $stmt->execute();
      $stmt->bind_result($ottl);
      while($stmt->fetch())
      {
      }
      $delcharge=0;
      $sql9="SELECT `deliveryBoyId` FROM `deliveryboy` WHERE `assignedTo`=?";
      $stmt9=$conn->prepare($sql9);
      $stmt9->bind_param("s",$mandal);
      $stmt9->execute();
      $stmt9->bind_result($delboyid);       
      while($stmt9->fetch())
      {
        switch($mandal){
          case 'Anantapur' : $delcharge=20;
                            break;
          case 'Bathalapalli' : $delcharge=37;
                            break;
          case 'Chennekothapalli' : $delcharge=60;
                            break;        
          case 'Dharmavaram' : $delcharge=52;
                            break;        
          case 'Garladinne' : $delcharge=29;
                            break;        
          case 'Kanagaanapalli' : $delcharge=54;
                            break;        
          case 'Narpala' : $delcharge=36;
                            break;        
          case 'Pamidi' : $delcharge=45;
                            break;        
          case 'Raptadu' : $delcharge=21;
                            break;        
          case 'Tadimarri' : $delcharge=49;
                            break; 
          default : echo "Something Wrong";                         
        }
      }

      $total=$ottl+$delcharge;
      $conn=new mysqli("localhost","root","","f2c");
      $sql1="UPDATE `orders` SET `deliveryBoyId`=?, `deliveryCharge`=?, `totalPay`=?, `deliveryAddress`=? WHERE `orderId`=?";
      $stmt1=$conn->prepare($sql1);
      $stmt1->bind_param("sssss",$delboyid,$delcharge,$total,$addr,$orderid);
      $stmt1->execute();
      if($stmt1->affected_rows==1)
      {
		    echo "<script>
              window.alert('Delivery Address Changed Successfully.');
            </script>";       
      }
      else
      {
		    echo "<script>window.alert('Something Wrong Try Again ..');</script>";
      }
    }
    ?>
        </div>
      </div>
    </div>
    <div class="col-4">
    </div>
  </div>
</div>
<?php
    require_once('backgroundfoot.php');
  }
  }
}
else
{
  header('Location: userlogin.php');
}
?>  