<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  $orderid=$_GET['oid'];
  $cost=$_GET['ttl'];
  if(!empty($orderid) && !empty($cost))
  {
    require_once('backgroundhead.php');
    require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4">
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <h1 class="center"><u>Payment</u></h1><br/>
          <form action="" method="post">
            <table align="center">
              <tr>
                <td>Name On Card</td>
                <td>
                  : <input type="text" name="name" placeholder="Name on Card" required/>
                </td>
              </tr>
              <tr>
                <td>Card Number</td>
                <td>
                  : <input type="text" name="number" maxlength="16" placeholder="Card Number" required />
                </td>
              </tr>
              <tr>
                <td>CVV Number</td>
                <td>: <input type="text" name="cvv" maxlength="3" placeholder="CVV" required /></td>
              </tr>
              <tr>
                <td>Total</td>
                <td>: <input type="text" name="cost" value="<?php echo $cost; ?>" readonly/>
                </td>
              </tr>
              <tr>
                <td>
                  <center><br/><a href="userorders.php"> <button type="button" class="tbtn btn-dark center">&nbsp;&nbsp;&nbsp;Back&nbsp;&nbsp;&nbsp;</button></a></center>
                </td>
                <td>
                  <center><br/><button type="submit" name="sub" class="tbtn btn-dark">&nbsp;&nbsp;&nbsp;&nbsp;Pay&nbsp;&nbsp;&nbsp;&nbsp;</button></center>
                </td>
              </tr>
            </table>            
          </form>
          <br/>
        </div>
      </div>
    </div>
    <div class="col-4">
    </div>
  </div>
</div>

<?php
    if(isset($_POST['sub']))
    {
      $pay="Paid";
      $conn=new mysqli("localhost","root","","f2c");
      $sql="UPDATE `orders` SET `payment`=? WHERE `orderId`=?";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("ss",$pay,$orderid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
		    echo "<script>
              window.alert('Paid Successfully.');
            </script>";       
      }
      else
      {
		    echo "<script>window.alert('Something Wrong Try Again ..');</script>";
      }
    }
    require_once('backgroundfoot.php');
  }
}
else
{
  header('Location: userlogin.php');
}

?>  