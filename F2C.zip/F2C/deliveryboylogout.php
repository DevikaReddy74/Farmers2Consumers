<?php
session_start();
if(!empty($_SESSION['deliveryboy']))
{
	unset($_SESSION['deliveryboy']);
    header('Location: deliveryboylogin.php');
}
else
{
    header('Location: deliveryboylogin.php');
}
?>