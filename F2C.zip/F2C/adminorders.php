<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmerid=$_SESSION['id'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-2">
    </div>
    <div class="col-8">
      <h1 class="center white"><u>Your Product Orders</u></h1>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <table border='1' align='center' class='center'>
            <tr>
              <th>&nbsp;S.NO&nbsp;</th>
              <th>&nbsp;Product ID&nbsp;</th>
              <th>&nbsp;Name&nbsp;</th>
              <th>&nbsp;Product&nbsp;</th>
              <th>&nbsp;Quantity&nbsp;</th>
              <th>&nbsp;₹ Cost /KG&nbsp;</th>
              <th>&nbsp;&nbsp;Total&nbsp;&nbsp;</th>
            </tr>
<?php
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT oi.`productId`, o.`userId`, p.`productName`, p.`image`, oi.`quantity`, oi.`price`, oi.`total` FROM `orderitems` oi JOIN `product` p ON oi.`productId`=p.`productId` JOIN `orders` o ON oi.`orderId`=o.`orderId` WHERE p.`farmerId`=? AND o.`status`=? ORDER BY oi.`productId`";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$farmerid,$status);
  $stmt1->execute();
  $stmt1->bind_result($pid,$usrid,$pname,$img,$quant,$price,$total);
  $count=0;
  while($stmt1->fetch())
  {
    $count++;
    echo "
            <tr>
		          <td>&nbsp;&nbsp;".$count."&nbsp;&nbsp;</td>
              <td>
						  	<a href='adminviewproduct.php?pid=$pid'>".$pid."</a>
							</td>
		          <td>&nbsp;&nbsp;".$pname."&nbsp;&nbsp;</td>
		          <td>&nbsp;<img src='".$img."' width='100' height='70' alt=".$pname." />&nbsp;</td>
		          <td>&nbsp;".$quant."&nbsp;</td>
		          <td>&nbsp;".$price."&nbsp;</td>
		          <td>&nbsp;₹ ".$total."&nbsp;</td>
		        </tr>";
  }
  if($count==0){
    echo "
            <tr>
		          <td colspan='6'><h1>Empty...!</h1></td>
		        </tr>";
  }
?>
          </table>
          <br/>
        </div>
      </div>
    </div>
    <div class="col-2">
    </div>
	</div>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}
?>