<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $boy=$_GET['dbid'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
      <div class='card' style='width: auto;'>
				<div class='card-body'>
          <h1 class="center"><u>Orders</u></h1><br/>
          <table class='center' border='1' align='center'>
		  	    <tr>
              <th>&nbsp;&nbsp;&nbsp;ID No&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Delivery Address&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Amount ₹&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Payment&nbsp;&nbsp;&nbsp;</th>
            </tr>
<?php
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `orderId`, `userId`, `totalPay`, `payment`, `status`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `status`=? AND `deliveryBoyId`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("ss",$status,$boy);
  $stmt->execute();
  $stmt->bind_result($orid,$uid,$total,$pay,$stat,$oon,$delon,$addr);
  $a=0;
  while($stmt->fetch())
  {
    $a++;
    echo "
              <tr>
                <td>&nbsp;".$orid."&nbsp;</td>
                <td>".$addr."</td>
                <td>&nbsp;₹ ".$total."&nbsp;</td>
                <td>&nbsp;".$pay."&nbsp;</td>
              </tr>
		  ";
    }

  if($a==0)
  {
    echo "          
          <tr>
            <td colspan='5'><br/><h1>Empty</h1><br/></td>      
          </tr>";
  }
  echo "
            </table>
      <div>
    </div>
  </div> 
  <br/>
</div>";

  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}

?>