<?php
session_start();
if(!empty($_SESSION['admin']))
{
 if(!empty($_GET['farid']))
 {
  $farmer=$_GET['farid'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col">
      <h1 class="center white"><u>Products</u></h1><br/>
  	  <div class='row row-cols-4'>
<?php

  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `productId`, `productName`, `image`, `price`, `quantity`, `description`, `category`, `type`, `available` FROM `product` WHERE `farmerId`=?4";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$farmer);
  $stmt->execute();
  $stmt->bind_result($pid,$pname,$product,$pprice,$pquant,$pdes,$pcat,$ptype,$avail);
  $a=0;
  while($stmt->fetch())
  {
    $a=1;
	echo "	
        <div class='col'>
	        <div class='card' style='width: auto;'>
            <img class='card-img-top' src='".$product."' alt='".$pname."' height='200'>
            <div class='card-body'>
	            <table align='center'>
                <tr>
		              <td>Id</td>
          			  <td>: ".$pid."</td>
		            </tr>	
		            <tr>
		              <td>Name</td>
          			  <td>: ".$pname."</td>
		            </tr>		 
		            <tr>
		              <td>Price ₹ </td>
			            <td>: ".$pprice." /KG</td>
		            </tr>		 
		            <tr>
		              <td>Available</td>
			            <td>: ".$pquant." KGs</td>
		            </tr>		 
		            <tr>
		              <td>Category</td>
			            <td>: ".$pcat."</td>
		            </tr>	
		            <tr>
		              <td>Type</td>
			          <td>: ".$ptype."</td>
		            </tr>
		            <tr>
		              <td>Available</td>
			            <td>: ".$avail."</td>
		            </tr>		 
		            <tr>
		              <td colspan='2'><br/></td>
		            </tr>
                <tr>
		              <td colspan='2'>".$pdes."</td>
		            </tr>
		            <tr>
		              <td colspan='2'>
    		            <a href='adminviewfeedback.php?proid=$pid'>
                      <button type='button' name='button' class='btn btn-dark'>
                      View Comments</button>
                    </a>  
		   	          </td>
                </tr>
              </table>		 
	          </div>
            
          </div>
	      </div>"; 
  }
  echo "
      </div>
    </div>
  </div>
</div>";

  if($a==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>Empty..!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
  require_once('backgroundfoot.php');
  }
  else{
    header('Location: adminallfarmers.php');
  }
}
else
{
  header('Location: adminlogin.php');
}
?>