<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>


<div class="alert">
  <div class="row">
    <div class="col">
	</div>
    <div class="col">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" enctype="multipart/form-data" align="center">
         <table align="center">
           <tr>
             <td colspan="2">
               <h1><u>Change Password</u></h1><br/>
             </td>
           </tr>
           <tr>
             <td>
               <input type="password" name="opwd" placeholder="Old Password" required/>
             </td>
           </tr>
             <td>
               <input type="password" name="npwd" placeholder="New Password" required/>
             </td>
           </tr>
           </tr>
             <td><br/></td>
           </tr>
           <tr>
             <td align="center">
               <button type="submit" name="ucps" class='btn btn-dark'>Update</button>
             </td>
           </tr>
         </table>
         <br/>
       </form>
      </div>
	 </div>
	</div>
   <div class="col">
   </div>
  </div>
</div>

<?php
  if(isset($_POST['ucps']))
  {
    $opwd=$_POST['opwd'];
    $npwd=$_POST['npwd'];  
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="SELECT `password` FROM `user` WHERE `userId`=?";
    $stmt1=$conn->prepare($sql1);
    $stmt1->bind_param("s",$userid);
    $stmt1->execute();
    $stmt1->bind_result($pass);
    $a=0;
    while($stmt1->fetch())
    {
      $a=1;
    }
    if($a==1)
    {
      $verify=password_verify($opwd,$pass);
      if($verify){
        $pass=password_hash($npwd,PASSWORD_DEFAULT);
        $sql2="UPDATE `user` SET `password`=? WHERE `userId`=?";
        $stmt2=$conn->prepare($sql2);
        $stmt2->bind_param("ss",$pass,$userid);
        $stmt2->execute();
        if($stmt2->affected_rows==1)
        {
          echo "<script>window.alert('Password Updated successfully');</script>";
        }
        else
        { 
          echo "<script>window.alert('Not Updated');</script>";
        }
      }
      else{
        echo "<script>window.alert('Wrong Password');</script>";
      }
    }
  }

  
  require_once('backgroundfoot.php');
}
else
{
  header('Location: userlogin.php');
}
?>