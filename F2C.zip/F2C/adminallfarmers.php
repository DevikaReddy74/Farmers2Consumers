<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
        <div class='card' style='width: auto;'>
          <br/><h1 class="center"><u>Farmers Details</u></h1>
	  			<div class='card-body'>
      <table border="1" align="center">
         <tr>
           <th>S.No</th>
           <th>Picture</th>
           <th>Name</th>
           <th>Gender</th>
           <th>DOB</th>
           <th>Contact</th>
           <th>Email</th>
           <th>Address</th>
           <th>Products</th>
         </tr>
<?php
$data=0;
 $conn=new mysqli("localhost","root","","f2c");
 $sql="SELECT `farmerId`, `image`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `registerDate`, `updateOn` FROM `farmer` WHERE `password`!=?";
 $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$data);
 $stmt->execute();
 $stmt->bind_result($farmerid,$img,$fname,$gen,$dob,$phone,$mail,$addr,$regdate,$update);
 $a=0;
 $i=1;
 while($stmt->fetch())
 {
  $a=1;
  echo "  <tr>
          <td>".$i."</td>
          <td><img src='".$img."' height='50%' width='80' alt='image'/></td>
          <td>".$fname."</td>
          <td>".$gen."</td>
          <td>".$dob."</td>
          <td>".$phone."</td>
          <td>".$mail."</td>
          <td>".$addr."</td>
          <td>
            <a href='adminviewfarmerproducts.php?farid=$farmerid'>
              <button type='button' class='btn btn-dark'>View</button>
            </a>
          </td>
         </tr>";
  $i++;
 }
 if($a==0)
 {
  echo " <tr>
          <td colspan='10'>
            <h1 align='center'>Empty!<h1/>
          </td>
         </tr>";
 }
 if(!empty($_GET['fid']))
 {
  $farmer=$_GET['fid'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `farmer` WHERE `farmerId` = ? ");
  $stmt->bind_param("s",$farmer);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
   echo "
    <script>
      window.alert('Farmer Deleted successfully');
    </script>";
  }
  else
  {
   echo "<script>window.alert('Farmer Not Deleted');</script>";
  }
 }
?>
      </table>
      <br/>
    </div>
    <div class="col-1">
    </div>
  </div>
  <br/><br/>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>