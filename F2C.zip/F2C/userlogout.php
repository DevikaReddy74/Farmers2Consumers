<?php
session_start();
if(!empty($_SESSION['user']))
{
 unset($_SESSION['user']);
 unset($_SESSION['item']);
 header('Location: userlogin.php');
}
else
{
 header('Location: userlogin.php');
}
?>