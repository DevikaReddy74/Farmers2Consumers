<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $proid=$_GET['pid'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>

<div class="alert">
  <h1 class="center white"><u>Product Details</u></h1><br/>
  <div class="row">    
    <div class="col-2">
    </div>
    <div class="col-4 center">
      
<?php
  //For displaying product
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `productName`, `image`, `price`, `quantity`, `description`, `category`, `type` FROM `product` WHERE `productId`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("s",$proid);
  $stmt1->execute();
  $stmt1->bind_result($pname,$product,$pprice,$quant,$des,$cat,$type);
  while($stmt1->fetch()){
  echo '
      <div class="card" style="width: auto;">
        <img class="card-img-top" src="'.$product.'" alt="'.$pname.'">
        <div class="card-body">
          <h3>'.$pname.'<br/>Price ₹: '.$pprice.' /KG
          <br/>Available Quantity: '.$quant.' KGs
          <br/>'.$des.'</h3>
        </div>
      </div><br/><br/>';
  }
?>   
    </div>
    <div class="col-4 center">
      <div class="card" style="width: auto;">
        <div class="card-body">
          <h1 class="center"><u>Product Rating</u></h1><br/>
          <table border="1" align="center">
            <tr>
              <th>Name</th>
              <th>Rating</th>
              <th>Comment</th>
              <th>Time</th>
            </tr>

<?php
  //For displaying product
  $conn=new mysqli("localhost","root","","f2c");
  $sql5="SELECT u.`fullName`, f.`rating`, f.`comment`, f.`time` FROM `feedback` f JOIN `user` u ON  u.`userId`=f.`userId` WHERE `productId`=? ORDER BY f.`feedbackId` DESC";
  $stmt5=$conn->prepare($sql5);
  $stmt5->bind_param("s",$proid);
  $stmt5->execute();
  $stmt5->bind_result($fname,$rating,$comment,$time);
  $rate=0;
  $count=0;
  while($stmt5->fetch()){
    $count++;
    echo "
            <tr>
              <td>".$fname."</td>
              <td>".$rating."</td>
              <td>".$comment."</td>
              <td>".$time."</td>
            </tr>
    ";
    $rate+=$rating;
  }
  if($count==0){
      echo "         <tr>
              <td colspan='4'><h1>No Comments Yet</h1></td>
            </tr>";
  }
  else{
    $avgrate=$rate/$count;
    echo "         <tr>
              <td colspan='4'><h1>⭐ ".round($avgrate,1)."</h1></td>
            </tr>";
  }
?>
          </table>
        </div>
      </div>
    </div>
    <div class="col-2">
    </div>
  </div>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: userlogin.php');
}
?>