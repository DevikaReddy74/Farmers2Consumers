/* Database name - `f2c` */


/* Creating `admin` database */
CREATE table `admin`(
    `farmerId` int(1) PRIMARY KEY NOT NULL DEFAULT 0,
    `userName` varchar(15) NOT NULL,
    `image` varchar(30) NOT NULL DEFAULT './images/profilepic.png',
    `fullName` varchar(15) NOT NULL,
    `gender` varchar(6) NOT NULL,
    `dob` varchar(10) NOT NULL,
    `phoneNo` varchar(10) NOT NULL,
    `emailId` varchar(30) NOT NULL,
    `address` varchar(150) NOT NULL,
    `password` varchar(80) NOT NULL,
    `updateOn` varchar(20) NULL
);

/* Inserting data into `admin` database */
/* Password is "ad" */
/* 
INSERT INTO `admin`(`farmerId`, `userName`, `password`) 
VALUES (0,`admin`,`$2y$10$EOVKy3sJNA8XEPqBCP8e/OPzGzki3O/QEXZN2L314oD9HctXi68t.`);

INSERT INTO `admin`(`farmerId`, `userName`, `fullName`, `gender`, `phoneNo`, `emailId`, `address`, `password`) VALUES (0,`admin`,`DevikaReddy`,`female`,`9876541230`,`admin@gmail.com`,`9-5<br/>Malakapuram<br/>Dharmavaram<br/>Anantapur<br/>515672`,`$2y$10$EOVKy3sJNA8XEPqBCP8e/OPzGzki3O/QEXZN2L314oD9HctXi68t.`);
*/





/* Creating `user` database */
CREATE table `user`(
    `userId` int(255) AUTO_INCREMENT PRIMARY KEY,
    `userName` varchar(15) UNIQUE KEY NOT NULL,
    `image` varchar(30) NOT NULL DEFAULT './images/profilepic.png',
    `fullName` varchar(15) NOT NULL,
    `gender` varchar(6) NOT NULL,
    `dob` varchar(10) NOT NULL,
    `phoneNo` varchar(10) UNIQUE KEY NOT NULL,
    `emailId` varchar(30) UNIQUE KEY NOT NULL,
    `address` varchar(150) NOT NULL,
    `mandal` VARCHAR(20) NOT NULL,
    `password` varchar(80) NOT NULL DEFAULT 0,
    `registerDate` varchar(20) NOT NULL,
    `updateOn` varchar(20) NULL
    );





/* Creating `farmer` database */
CREATE table `farmer`(
    `farmerId` int(255) AUTO_INCREMENT PRIMARY KEY,
    `userName` varchar(15) UNIQUE KEY NOT NULL,
    `image` varchar(30) NOT NULL DEFAULT './images/profilepic.png',
    `fullName` varchar(15) NOT NULL,
    `gender` varchar(6) NOT NULL,
    `dob` varchar(10) NOT NULL,
    `phoneNo` varchar(10) UNIQUE KEY NOT NULL,
    `emailId` varchar(30) UNIQUE KEY NOT NULL,
    `address` varchar(100) NOT NULL,
    `password` varchar(80) NOT NULL DEFAULT 0,
    `registerDate` varchar(20) NOT NULL,
    `updateOn` varchar(20) NULL
);





/* Creating `product` database */
CREATE table `product`(
    `productId` int(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `farmerId` int(255) NOT NULL,
    `productName` varchar(15) NOT NULL,
    `image` varchar(30) NOT NULL,
    `price` varchar(5) NOT NULL,
    `quantity` varchar(10) NOT NULL,
    `description` varchar(100) NOT NULL,
    `category` varchar(15) NOT NULL,
    `type` varchar(15) NOT NULL,
    `createdOn` varchar(20) NOT NULL,
    `available` varchar(3) NOT NULL DEFAULT 'yes',
    `updateOn` varchar(20) NULL
);

/* Changing `product`s `farmerId` as FOREIGN KEY */
ALTER TABLE `product`
ADD CONSTRAINT `product_farmer` 
FOREIGN KEY (`farmerId`) REFERENCES `farmer` (`farmerId`);





/* Creating `cart` database */
CREATE TABLE `cart`(
    `cartId` int(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `userId` int(255) NOT NULL,
    `productId` int(255) NOT NULL,
    `quantity` varchar(10) NOT NULL  DEFAULT '1',
    `total` varchar(10) NOT NULL,
    `status` varchar(5) NOT NULL  DEFAULT 'cart'
);

/* Changing `cart`s `userId` as FOREIGN KEY */
ALTER TABLE `cart`
ADD CONSTRAINT `cart_user` 
FOREIGN KEY (`userId`) REFERENCES `user` (`userId`);

/* Changing `cart`s `productId` as FOREIGN KEY */
ALTER TABLE `cart`
ADD CONSTRAINT `cart_product` 
FOREIGN KEY (`productId`) REFERENCES `product` (`productId`);






/* Creating `orders` database */
CREATE TABLE `orders`(
    `orderId` int(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `userId` int(255) NOT NULL,
    `deliveryBoyId` int(255) NOT NULL,
    `orderTotal` varchar(10) NOT NULL,
    `deliveryCharge` varchar(3) NOT NULL,
    `totalPay` varchar(10) NOT NULL,
    `payment` varchar(8) NOT NULL,
    `status` varchar(10) NOT NULL  DEFAULT 'Ordered',
    `orderOn` varchar(20) NOT NULL,
    `deliverOn` varchar(20) NOT NULL,
    `deliveryCode` varchar(6) NOT NULL,
    `deliveryAddress` varchar(150) NOT NULL
);

/* Changing `orders`s `userId` as FOREIGN KEY */
ALTER TABLE `orders`
ADD CONSTRAINT `orders_user` 
FOREIGN KEY (`userId`) REFERENCES `user` (`userId`);

/* Changing `orders`s `deliveryBoyId` as FOREIGN KEY */
ALTER TABLE `orders`
ADD CONSTRAINT `orders_deliveryBoy` 
FOREIGN KEY (`deliveryBoyId`) REFERENCES `deliveryboy` (`deliveryBoyId`);






/* Creating `orderitems` database */
CREATE TABLE `orderitems`(
    `orderItemId` int(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `orderId` int(255) NOT NULL,
    `productId` int(255) NOT NULL,
    `quantity` varchar(10) NOT NULL,
    `price` varchar(5) NOT NULL,
    `total` varchar(10) NOT NULL
);

/* Changing `orderitems`s `orderId` as FOREIGN KEY */
ALTER TABLE `orderitems`
ADD CONSTRAINT `orderitems_order` 
FOREIGN KEY (`orderId`) REFERENCES `orders` (`orderId`);

/* Changing `orderitems`s `productId` as FOREIGN KEY */
ALTER TABLE `orderitems`
ADD CONSTRAINT `orderitems_product` 
FOREIGN KEY (`productId`) REFERENCES `product` (`productId`);



/* Creating `feedback` database */
CREATE TABLE `feedback`(
    `feedbackId` int(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `productId` int(255) NOT NULL,
    `userId` int(255) NOT NULL,
    `rating` varchar(1) NOT NULL,
    `comment` varchar(40) NOT NULL,
    `time` varchar(20) NOT NULL
);

/* Changing `feedback`s `productId` as FOREIGN KEY */
ALTER TABLE `feedback`
ADD CONSTRAINT `feedback_product` 
FOREIGN KEY (`productId`) REFERENCES `product` (`productId`);

/* Changing `feedback`s `userId` as FOREIGN KEY */
ALTER TABLE `feedback`
ADD CONSTRAINT `feedback_user` 
FOREIGN KEY (`userId`) REFERENCES `user` (`userId`);



/* Creating `deliveryBoy` database */
CREATE table `deliveryBoy`(
    `deliveryBoyId` int(255) AUTO_INCREMENT PRIMARY KEY,
    `fullName` varchar(15) NOT NULL,
    `image` varchar(30) NOT NULL,
    `gender` varchar(6) NOT NULL,
    `dob` varchar(10) NOT NULL,
    `phoneNo` varchar(10) UNIQUE KEY NOT NULL,
    `emailId` varchar(30) UNIQUE KEY NOT NULL,
    `address` varchar(150) NOT NULL,
    `assignedTo` varchar(20) UNIQUE KEY NOT NULL,
    `registerDate` varchar(20) NOT NULL,
    `updateOn` varchar(20) NULL,
    `password` varchar(80) NOT NULL
);