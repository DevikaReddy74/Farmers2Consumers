<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4">

      <br/>
<?php
  $farmerid=$_GET['fid'];
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `Image`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address` FROM `farmer` WHERE `farmerId`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$farmerid);
  $stmt->execute();
  $stmt->bind_result($img,$fname,$gen,$dob,$phno,$email,$addr);
  $a=0;
  while($stmt->fetch())
  {
    $a=1;
  }
  if($farmerid==0){
    $conn=new mysqli("localhost","root","","f2c");
    $sql="SELECT  `Image`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address` FROM `admin` WHERE `farmerId`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s",$farmerid);
    $stmt->execute();
    $stmt->bind_result($img,$fname,$gen,$dob,$phno,$email,$addr);
    $a=0;
    while($stmt->fetch())
    {
      $a=1;
    }
  }
  if($a==1)
  {
    echo '
      <div class="card" style="width: auto;">
            <h1 class="center"><u>Farmer Details</u></h1><br/>
        <h4>
        <form action="" method="post">
          <table border="0" align="center">
            <tr>
              <td colspan="2" align="center">
                <img src="'.$img.'" height="170" width="150" alt="image" class="rounded-circle" />
              </td>
            </tr>
            <tr>
              <td>Full Name</td>
              <td>: '.$fname.'</td>
            </tr>
            <tr>
              <td>Date of Birth </td>
              <td>: '.$gen.'</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>: '.$dob.'</td>
            </tr>
            <tr>
              <td>Phone No</td>
              <td>: '.$phno.'</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>: '.$email.'</td>
            </tr>
            <tr>
              <td>Address</td>
              <td>: '.$addr.'</td>
            </tr>
	          <tr>
	            <td colspan="2"><br/></td>
	          </tr>
            <tr>
		          <td colspan="2" class="center">
    		        <a href="adminallproducts.php">
                  <button type="button" name="button" class="btn btn-dark">Back
                  </button>
                </a>  
		          </td>
	          </tr>
          </table>
          <br/>
        </form>
        </h4>
	    </div>
    ';
  }
  else{
		echo "<script>window.alert('Farmer details not found');</script>";
  }  
?>

    </div>
    <div class="col-4">
    </div>
  </div>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}

?>