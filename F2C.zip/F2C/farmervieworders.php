<?php
session_start();
if(!empty($_SESSION['farmer']))
{
  $farmerid=$_SESSION['farmer'];
  require_once('backgroundhead.php');
  require_once('farmermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-12">
      <h1 class="center white"><u>Your Product Orders</u></h1><br/>
      <div class='row row-cols-4'>

<?php
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `orderId`, `orderTotal`, `deliveryCharge`, `totalPay`, `payment`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `userId`=? AND `status`=?";
 $stmt->bind_param("s",$farmerid);
 $stmt->execute();
 $stmt->bind_result($oid,$userid,$pid,$pro,$pname,$quant,$cost,$total,$pay);
 $a=0;
 $i=0;
 while($stmt->fetch())
 {
     echo "<div class='col'>
     <div class='card' style='width: 20rem;'>
      <div class='card-body'>
       <table border='0' align='center'>
         <tr>
		   <td colspan='2'><h3>".$oid."</h3></td>
		 </tr>
		 <tr>
		   <td colspan='2'><a href='farmervieworders.php?addr=$userid'>Address</a></td>
		 </tr>
         <tr>
		   <td colspan='2'><br/></td>
		 </tr>
         <tr>
		   <td>Product</td>
		   <td><img src='".$pro."' height='50' width='50'/></td>
		 </tr>
         <tr>
		   <td>Product Name</td>
		   <td>".$pname."</td>
		 </tr>
         <tr>
		   <td>Quantity</td>
		   <td>".$quant."</td>
		 </tr>
         <tr>
		   <td>Cost</td>
		   <td>".$cost."</td>
		 </tr>
         <tr>
		   <td>Total</td>
		   <td>".$total."</td>
		 </tr>*
         <tr>
		   <td>Payment</td>
		   <td>".$pay."</td>
		 </tr>
	   </table>";

      for($k=$j+1;$k<$i;$k++)
      {
	    if($poid[$j]==$poid[$k])
	    {
		  echo "
          <table border='0' align='center'>
           <tr>
		    <td colspan='2'><br/></td>
		   </tr>
           <tr>
		    <td colspan='2'><br/></td>
		   </tr>
           <tr>
		    <td>Product</td>
		    <td><img src='".$ppro[$k]."' height='50' width='50'/></td>
		   </tr>
           <tr>
		    <td>Product Name</td>
		    <td>".$ppname[$k]."</td>
		   </tr>
           <tr>
		    <td>Quantity</td>
		    <td>".$pquant[$k]."</td>
		   </tr>
           <tr>
		    <td>Cost</td>
		    <td>".$pcost[$k]."</td>
		   </tr>
           <tr>
		    <td>Total</td>
		    <td>".$ptotal[$k]."</td>
		   </tr>
           <tr>
		    <td>Payment</td>
		    <td>".$ppay[$k]."</td>
		   </tr>
	      </table>";
	    }
      }
	 echo "
	   </div>
	 </div>
	</div>";

 }

 if($a==0)
 {
  echo "<h2>EMPTY!.....</h2>";
 }

?>
    </div>
	</div>
<?php
 if(!empty($_GET['addr']))
 {
  $auserid=$_GET['addr'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("SELECT `Fullname`, `Phoneno`, `Emailid`, `Address` FROM `userregister` WHERE `Userid` = ? ");
  $stmt->bind_param("s",$auserid);
  $stmt->execute();
  $stmt->bind_result($fname,$phone,$mail,$addr);
  $b=0;
  while($stmt->fetch())
  {
   $b=1;
  }
  if($b==1)
  {
   echo "
    <h3 align='center'>
     <u>".$fname."</u>
    </h3>
    <table border='1' align='center'>
    <tr>
     <td>Name</td>
     <td>".$fname."</td>
    </tr>
    <tr>
     <td>Phone no</td>
     <td>".$phone."</td>
    </tr>
    <tr>
     <td>Mail id</td>
     <td>".$mail."</td>
    </tr>
    <tr>
     <td>Address</td>
     <td>".$addr."</td>
    </tr>
   </table>";
  }
 }
?>
     </div>
	</div>
  
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: farmerlogin.php');
}
?>