<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $data=$_GET['data'];
  if($data=='reject')
  {
    $farmer=$_GET['fidd'];
    $conn=new mysqli("localhost","root","","f2c");
    $stmt=$conn->prepare("DELETE FROM `farmer` WHERE `farmerId` = ? ");
    $stmt->bind_param("s",$farmer);
    $stmt->execute();
    if($stmt->affected_rows>0)
    {
      /* Mailing working online
      $sub="Password for login";
      $msg="Dear ".$fn." <br/> Your registration in farmers2Consumers app is rejected.";
      $fromMail="From:devikadvks77@gmail.com \r\n";
      $res=mail($userMail,$sub,$msg,$fromMail);
      if($res){
        echo "Message sent";
      }
      else{
        echo "Error";
      }
      */
      echo "
      <script>
        window.alert('Farmer Deleted successfully');
      </script>";  

    }
    else
    {
      echo "<script>window.alert('Farmer Not Deleted');</script>";
    }
    header('Location: adminacceptrejectfarmers.php');

  }
  if($data=='accept')
  {
    $farmer=$_GET['fida'];

    $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $mixedStr=str_shuffle($str);
  
    //$pass=substr($mixedStr,0,6);
    $pass="adevika";

    /* Mailing working online
    $sub="Password for login";
    $msg="Dear ".$fn." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
    $fromMail="From:devikadvks77@gmail.com \r\n";
    $res=mail($userMail,$sub,$msg,$fromMail);
    if($res){
      echo "Message sent";
    }
    else{
      echo "Error";
    }
    */


    $pr=password_hash($pass,PASSWORD_DEFAULT);

    $conn=new mysqli("localhost","root","","f2c");
    $sql2="UPDATE `farmer` SET `password`=? WHERE `farmerId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("ss",$pr,$farmer);
    $stmt2->execute();
    if($stmt2->affected_rows>0)
    {
    echo "
      <script>
        window.alert('Accepted successfully');
      </script>";
    }
    else
    {
      echo "<script>window.alert('Something Wrong');</script>";
    }
    header('Location: adminacceptrejectfarmers.php');
  }
}
else
{
  header('Location: adminlogin.php');
}
?>