<?php
session_start();
require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<br/>
<div class="alert">
  <div class="row">
    <div class="col-4">
	</div>
    <div class="col-4">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" align="center">
        <h1><u>User Registration</u></h1><br/>
        <table border="0" align="center">
          <tr>
            <td>Full Name</td>
            <td>
              <input type="text" name="fn" maxlength="25" required/>
            </td>
          </tr>
          <tr>
            <td>Gender</td>
            <td>
              <input type="radio" name="ge" value="Male" required/>
              Male
              <input type="radio" name="ge" value="Female" required/>
              Female
            </td>
          </tr>          
          <tr>
            <td>Date of Birth</td>
            <td>
              <input type="date" name="dob" required/>
            </td>
          </tr>
          <tr>
            <td>Phone No</td>
            <td><input type="text" name="ph" maxlength="10" required/>
            </td>
          </tr>
          <tr>
            <td>Email</td>
            <td>
              <input type="text" name="ma" maxlength="30" required/>
            </td>
          </tr>
          <tr>
            <td>User Name</td>
            <td>
              <input type="text" name="ur" maxlength="15" required/>
            </td>
          </tr>
          <tr>
            <td>Door No.</td>
            <td>
              <input type="text" name="dno" required/>
            </td>
          </tr>
          <tr>
            <td>Address Line</td>
            <td>
              <input type="text" name="addrline" required/>
            </td>
          </tr>          
          <tr>
            <td>Mandal</td>
            <td>
              <select name="mandal">
<?php
require_once('mandals.php');
?>
              </select>    
            </td>
          </tr>
          <tr>
            <td>District</td>
            <td>
              <select name="dist">
                <option>Anantapur</option>
              </select>     
            </td>
          </tr>
          <tr>
            <td>Pincode</td>
            <td>
              <input type="text" name="pincode" required/>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <input type="checkbox" name="cbox" value="tc" required/> By Clicking this you agree the <a href="userT&C.php">Terms & Conditions</a>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <button type="submit" name="urs" class="btn btn-dark">Register</button>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <h4>If Register? 
                <a href="userlogin.php">Login Here!</a>
              </h4>
            </td>
          </tr>
        </table>
       </form>
      </div>
     </div>
    </div>
    <div class="col-4">
	</div>
  </div>
</div>
<?php

if(isset($_POST['urs']))
{
  date_default_timezone_set("Asia/Calcutta");
  $date=date('d-m-Y H:i:s',time());
  $fn=$_POST['fn'];
  $ge=$_POST['ge'];
  $dob=$_POST['dob'];
  $ph=$_POST['ph'];
  $userMail=$_POST['ma'];
  $addr=$_POST['dno']."<br/>".$_POST['addrline']."<br/>".$_POST['mandal'].", ".$_POST['dist']."<br/>".$_POST['pincode'];
  $ur=$_POST['ur'];
  $mandal=$_POST['mandal'];

  $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  $mixedStr=str_shuffle($str);
  
  //$pass=substr($mixedStr,0,6);
  $pass="adevika";

  /* Mailing working online
  $sub="Password for login";
  $msg="Dear ".$fn." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
  $fromMail="From:devikadvks77@gmail.com \r\n";
  $res=mail($userMail,$sub,$msg,$fromMail);
  if($res){
    echo "Message sent";
  }
  else{
    echo "Error";
  }
  */


  $pr=password_hash($pass,PASSWORD_DEFAULT);

  $conn=new mysqli("localhost","root","","f2c");
  $sql="INSERT INTO `user`(`userName`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `mandal`, `registerDate`) VALUES (?,?,?,?,?,?,?,?,?)";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("sssssssss",$ur,$fn,$ge,$dob,$ph,$userMail,$addr,$mandal,$date);
  $stmt->execute();
  if($stmt->affected_rows==1)
  {
    echo "<script>window.alert('Once your profile will accepted by the admin then your password will sent to your respective mail Id.');</script>";
  }
  else
  {
    echo "<script>window.alert('Not Registered');</script>";
  }
}
require_once('backgroundfoot.php');
?>