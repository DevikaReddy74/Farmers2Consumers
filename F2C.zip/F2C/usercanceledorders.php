<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-12">
      <h1 class="center white"><u>Canceled Orders</u></h1>
      <div class='row row-cols-4'>
         
<?php    
  $status="Canceled";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `orderId`, `orderTotal`, `deliveryCharge`, `totalPay`, `payment`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `userId`=? AND `status`=? ORDER BY `orderId` DESC";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$userid,$status);
  $stmt1->execute();
  $stmt1->bind_result($id,$total,$delcharg,$totalpay,$pay,$oon,$delon,$deladdr);
  $c=0; 
  $empty=0;
  $ods=array(); 
  $ototal=array(); 
  $odelcharg=array(); 
  $ototalpay=array(); 
  $opay=array(); 
  $ooon=array(); 
  $odelon=array(); 
  $odeladdr=array(); 
  while($stmt1->fetch())
  {   
    $empty=1;
    $oids[$c]=$id;
    $ototal[$c]=$total;
    $odelcharg[$c]=$delcharg; 
    $ototalpay[$c]=$totalpay; 
    $opay[$c]=$pay; 
    $ooon[$c]=$oon;
    $odelon[$c]=$delon; 
    $odeladdr[$c]=$deladdr; 
    $c+=1;
  }
  for($i=0;$i<$c;$i++){
    $orid=$oids[$i];
    $sql2="SELECT oi.`quantity`, oi.`price`, oi.`total`, oi.`productId`, p.`productName`, p.`image` FROM `orderitems` oi JOIN `product` p ON p.`productId`=oi.`productId` WHERE `orderId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("s",$orid);
    $stmt2->execute();
    $stmt2->bind_result($oiquant,$oiprice,$oitotal,$oipid,$oiproname,$oiimag);
    $a=0; 
    $oid=array(); 
    echo "        
        <div class='col'>
          <div class='card' style='width: auto;'>
            <div class='card-body'>
              <table class='center'>
		            <tr>
			            <th>Product</th>
			            <th>Cost /KG</th>
                  <th>&nbsp;*&nbsp;</th>
                  <th>Quantity</th>
                  <th>&nbsp;=&nbsp;</th>
                  <th>Toatal</th>
			          </tr>
    ";    
    while($stmt2->fetch())
    {
      echo "             
		            <tr>
		        	    <td>
                    <a href='userviewitem.php?proid=$oipid'>
                      <img src='".$oiimag."' height='auto' width='50'/>
                      <br/>".$oiproname."
                    </a> 
                  </td>
                  <td>".$oiprice."</td>
                  <td>*</td>
                  <td>".$oiquant."</td>
                  <td>=</td>
                  <td>".$oitotal."</td>
			          </tr>
      ";
    }
    echo"	
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
                <tr>
                  <th colspan='5'>Total</th>
                  <th>".$ototal[$i]."</th>
                </tr>                
                <tr>
                  <th colspan='4'>Delivery Charge</th>
                  <th>+</th>
                  <th>".$odelcharg[$i]."</th>
                </tr>
                <tr>
                  <th colspan='4'></th>
                  <th colspan='2'>________</th>
                </tr>                
                <tr>
                  <th colspan='5'>Total Amount to Pay</th>
                  <th>".$ototalpay[$i]."</th>
                </tr>
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
                <tr>
                  <th colspan='2'>Order On</th>
                  <th colspan='4'>".$ooon[$i]."</th>
                </tr>
                <tr>
                  <td colspan='6'><br/></td>
                </tr>
                <tr>
                  <th colspan='2'>Payment</th>
                  <th colspan='4'>".$opay[$i]."</th>
                </tr>  
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
              </table>
              <table>           
                <tr>
                  <th>Address :-</th>
                </tr>                  
                <tr>
                  <td>
                  ".$odeladdr[$i]."</td>
                </tr>                                   
              </table>
              <br/>                       
            </div>
          </div>
        </div>";
  } 
?>
      </div> 
    </div>
  </div>
</div>

<?php
  if($empty==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>EMPTY...!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
  require_once('backgroundfoot.php');
}
else
{
  header('Location: userlogin.php');
}

?>  