<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $data=$_GET['data'];
  if($data=='reject')
  {
    $user=$_GET['uidd'];
    $conn=new mysqli("localhost","root","","f2c");
    $stmt=$conn->prepare("DELETE FROM `user` WHERE `userId` = ? ");
    $stmt->bind_param("s",$user);
    $stmt->execute();
    if($stmt->affected_rows>0)
    {
      /* Mailing working online
      $sub="Password for login";
      $msg="Dear ".$fn." <br/> Your registration in farmers2Consumers app is rejected.";
      $fromMail="From:devikadvks77@gmail.com \r\n";
      $res=mail($userMail,$sub,$msg,$fromMail);
      if($res){
        echo "Message sent";
      }
      else{
        echo "Error";
      }
      */
      echo "
      <script>
        window.alert('User Deleted successfully');
      </script>";  

    }
    else
    {
      echo "<script>window.alert('User Not Deleted');</script>";
    }
    header('Location: adminacceptrejectusers.php');

  }
  if($data=='accept')
  {
    $user=$_GET['uida'];

    $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $mixedStr=str_shuffle($str);
  
    //$pass=substr($mixedStr,0,6);
    $pass="adevika";

    /* Mailing working online
    $sub="Password for login";
    $msg="Dear ".$fn." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
    $fromMail="From:devikadvks77@gmail.com \r\n";
    $res=mail($userMail,$sub,$msg,$fromMail);
    if($res){
      echo "Message sent";
    }
    else{
      echo "Error";
    }
    */


    $pr=password_hash($pass,PASSWORD_DEFAULT);

    $conn=new mysqli("localhost","root","","f2c");
    $sql2="UPDATE `user` SET `password`=? WHERE `userId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("ss",$pr,$user);
    $stmt2->execute();
    if($stmt2->affected_rows>0)
    {
    echo "
      <script>
        window.alert('Accepted successfully');
      </script>";
    }
    else
    {
      echo "<script>window.alert('Something Wrong');</script>";
    }
    header('Location: adminacceptrejectusers.php');

  }
}
else
{
  header('Location: adminlogin.php');
}
?>