<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col">
      <h1 class="white center"><u>Your Wishlist</u></h1>
      <div class='row row-cols-4'>
<?php

  $status="wish";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT c.`cartId`, c.`productId`, p.`image`, p.`productName`, p.`price` FROM `cart` c JOIN `product` p ON p.`productId`=c.`productId` WHERE c.`userId`=? AND c.`status`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$userid,$status);
  $stmt1->execute();
  $stmt1->bind_result($cartid,$pid,$pro,$pname,$pcost);

  $a=0;
  while($stmt1->fetch())
  {
    $a=1;
    echo "
        <div class='col'>
        <div class='card' style='width: auto;'>
          <div class='card-body'>
            <table>
		          <tr>
			          <td colspan='2'>
                    <a href='userviewitem.php?proid=$pid'>
                <img src='".$pro."' height='50' width='50'/></a></td>
			        </tr>
		          <tr>
			          <td>
                    <a href='userviewitem.php?proid=$pid'>
                
                Product Name</a></td>
			          <td>
                    <a href='userviewitem.php?proid=$pid'>
                
                : ".$pname."</a></td>
			        </tr>
		          <tr>
			          <td>Cost Per KG</td>
			          <td>: ".$pcost."</td>
			        </tr>
		          <tr>
			          <td colspan='2' class='center'>
			            <a href='usercartstatuschange.php?cartid=$cartid&status=cart'>
                    <button type='button' class='btn btn-dark'>Add to Cart</button>
                  </a>
			          </td>
			        </tr>
		        </table>
	        </div>
        </div>
        </div>";
 }
 ?>
      </div>
    </div>
  </div>
</div>

<?php

if($a==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>EMPTY...!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
 }
  require_once('backgroundfoot.php');
}
else
{
 header('Location: userlogin.php');
}
?>