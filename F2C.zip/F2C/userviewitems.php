<?php
session_start();
if(!empty($_SESSION['user']))
{
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-12">
      <div class='row row-cols-4'>
<?php
  $protype=$_GET['itemtype'];
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `productId`, `productName`, `image`, `price` FROM `product` WHERE `type`=?";
  $stmt=$conn->prepare($sql); 
  $stmt->bind_param("s",$protype);
  $stmt->execute();
  $stmt->bind_result($pid,$pname,$product,$pprice);
  $a=0;
  $pids=array();
  $pnames=array();
  $products=array();
  $pprices=array();
  while($stmt->fetch())
  {
    $pids[$a]=$pid;
    $pnames[$a]=$pname;
    $products[$a]=$product;
    $pprices[$a]=$pprice;
    $a++;
  }
  for($i=0;$i<$a;$i++){
    $proid=$pids[$i];
    $rating=0;
    $sql2="SELECT avg(`rating`) FROM `feedback` WHERE `productId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("s",$proid);
    $stmt2->execute();
    $stmt2->bind_result($ratings);
    $c=0;
    while($stmt2->fetch())
    {
      $rating=round($ratings,1);
    }
    echo "
        <div class='col center'>
          <div class='card' style='width: auto;'>
            <div class='card-body'>
              <a href='userviewitem.php?proid=$proid'>
                <img src='".$products[$i]."' height='100%' width='100%'/><br/>".$pnames[$i]."<br/>₹ ".$pprices[$i]." /KG<br/>⭐ ".$rating."
              </a>
	          </div>
          </div>
        </div>
    ";
  }
?>

      </div>   
    </div>
  </div>
</div>

<?php

  if($a==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>Not Available</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
  require_once('backgroundfoot.php');
}
else
{
  header('Location: userlogin.php');
}
?>