<?php
session_start();
if(!empty($_SESSION['farmer']))
{
  $farmerid=$_SESSION['farmer'];
  require_once('backgroundhead.php');
  require_once('farmermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-2">
    </div>
    <div class="col-8">
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <h1 class="center"><u>Your Product Orders</u></h1><br/>
          <table border='1' align='center' class='center'>
            <tr>
              <th>&nbsp;&nbsp;S.NO&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Product ID&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Name&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Product&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Quantity&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;₹ Cost /KG&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Total&nbsp;&nbsp;&nbsp;</th>
            </tr>
<?php
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT oi.`productId`, o.`userId`, p.`productName`, p.`image`, oi.`quantity`, oi.`price`, oi.`total` FROM `orderitems` oi JOIN `product` p ON oi.`productId`=p.`productId` JOIN `orders` o ON oi.`orderId`=o.`orderId` WHERE p.`farmerId`=? AND o.`status`=? ORDER BY oi.`productId`";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$farmerid,$status);
  $stmt1->execute();
  $stmt1->bind_result($pid,$usrid,$pname,$img,$quant,$price,$total);
  $count=0;
  while($stmt1->fetch())
  {
    $count++;
    echo "
            <tr>
		          <td>".$count."</td>
		          <td>".$pid."</td>
		          <td>&nbsp;".$pname."&nbsp;</td>
		          <td>&nbsp;<img src='".$img."' width='100' height='70' alt=".$pname." />&nbsp;</td>
		          <td>&nbsp;".$quant."&nbsp;</td>
		          <td>&nbsp;".$price."&nbsp;</td>
		          <td>&nbsp;₹ ".$total."&nbsp;</td>
		        </tr>";
  }
  if($count==0){
    echo "
            <tr>
		          <td colspan='6'><h1>Empty...!</h1></td>
		        </tr>";
  }
?>
          </table>
          <br/>
        </div>
      </div>
    </div>
    <div class="col-2">
    </div>
	</div>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: farmerlogin.php');
}
?>