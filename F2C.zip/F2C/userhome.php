<?php
session_start();
if(!empty($_SESSION['user']))
{
  echo "<meta HTTP-EQUIV='refresh' CONTENT='600' URL='userhome.php'>";
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col center">
      <form action="userviewitems.php" method="get">
        <select name="itemtype">
<?php
  require_once('producttypes.php');
?>
        </select>
        <button type="submit" class="btn btn-primary">Search</button>
      </form>
    </div>
  </div>
  <br/><br/>
  <div class="row">
    <div class="col">
      <div class='row row-cols-4'>
<?php
  $avail="yes";
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `productId`, `productName`, `image`, `type` FROM `product` WHERE `available`=? AND `quantity`>0 ORDER BY `productId` DESC";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$avail);
  $stmt->execute();
  $stmt->bind_result($proid,$pname,$product,$type);
  $a=0;
  $empty=0;
  $proids=array();
  $pnames=array();
  $products=array();
  $types=array();
  while($stmt->fetch())
  {
    $empty=1;
    $proids[$a]=$proid;
    $pnames[$a]=$pname;
    $products[$a]=$product;
    $types[$a]=$type;
    $a++;
  }
  for($i=0;$i<$a;$i++){
    $pid=$proids[$i];
    $rating=0;
    $sql2="SELECT avg(`rating`) FROM `feedback` WHERE `productId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("s",$pid);
    $stmt2->execute();
    $stmt2->bind_result($ratings);
    $c=0;
    while($stmt2->fetch())
    {
      $rating=round($ratings,1);
    }
      echo "
        <div class='col'>
	        <div class='card' style='width: auto;'>
            <div class='card-body'>
              <a href='userviewitems.php?itemtype=".$types[$i]."'>
                <table>
                  <tr>
                    <td colspan='2'>
                      <img src='".$products[$i]."' height='200' width='100%' alt='".$pnames[$i]."' id='img'/>
                    </td>
                  </tr>
                  <tr>
                    <td>".$pnames[$i]."</td>
                    <td>⭐ ".$rating."</td>
                  </tr>
                </table>
              </a>
            </div>
          </div>
        </div>
      ";
    
  }
 ?>
 

      </div>   
    </div>
  </div>
</div>
 
 <?php
 
  if($empty==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>EMPTY...!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
 }
  
 require_once('backgroundfoot.php');
}
else
{
 header('Location: userlogin.php');
}
?>