<?php
session_start();
require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<br/>
<div class="alert">
  <div class="row">
    <div class="col">
	  </div>
    <div class="col">	
	    <div class="card" style="width: auto;">
        <div class="card-body">
          <form action="" method="post" enctype="multipart/form-data" align="center">
            <table align="center">
            <tr>
              <td colspan="2">
                <h1><u>Forgot Password</u></h1><br/>
              </td>
            </tr>           
            <tr>
              <td colspan="2">
                If you forgot your password, Enter your Mail id. A password is sent to your mail. 
              </td>
            </tr>           
            <tr>
              <td colspan="2"><br/></td>
            </tr>
            <tr>
              <td colspan="2">
                <input type="text" name="mail" placeholder="Mail id" required/>
              </td>
            </tr>
            <tr>
              <td colspan="2"><br/></td>
            </tr>
            <tr>
              <td>
                <a href="deliveryboylogin.php">
                  <button type="button" name="btn" class="btn btn-dark">Back</button>
                </a>
              </td>
              <td>
                <button type="submit" name="dbfps" class="btn btn-dark">Submit</button>
              </td>
            </tr>
          </table>
          <br/>
          </form>
        </div>
	    </div>
	  </div>
    <div class="col">
    </div>
  </div>
</div>

<?php
if(isset($_POST['dbfps']))
{
  $mail=$_POST['mail'];
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `deliveryBoyId`, `emailId` FROM `deliveryboy` WHERE `emailId`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("s",$mail);
  $stmt1->execute();
  $stmt1->bind_result($dbid,$userMail);
  $a=0;
  while($stmt1->fetch())
  {
    $a=1;
  }
  if($a==1)
  {
    $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $mixedStr=str_shuffle($str);
  
    //$pass=substr($mixedStr,0,6);
    $pass="adevika";

    /* Mailing working online
    $sub="Password for login";
    $msg="Dear ".$fn." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
    $fromMail="From:devikadvks77@gmail.com \r\n";
    $res=mail($userMail,$sub,$msg,$fromMail);
    if($res){
      echo "Message sent";
    }
    else{
      echo "Error";
    }
    */

    $pr=password_hash($pass,PASSWORD_DEFAULT);
    $sql2="UPDATE `deliveryboy` SET `password`=? WHERE `deliveryBoyId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("ss",$pr,$dbid);
    $stmt2->execute();
    if($stmt2->affected_rows==1)
    {
      echo "<script>window.alert('Password Sent to your mail successfully');</script>";
    }
    else
    { 
      echo "<script>window.alert('Something wrong ..! Try again');</script>";
    }
  }
  else{
    echo "<script>window.alert('Entered Mailid is wrong/Not Found');</script>";
  }
}

  
  require_once('backgroundfoot.php');
?>