<?php
session_start();
if(!empty($_SESSION['user']))
{
  $cartid=$_GET['cartid'];
  $status=$_GET['status'];
  $cost=$_GET['cost'];
  if($status=="wish"){
    $quant=1;
    $total=$quant*$cost;
    $conn=new mysqli("localhost","root","","f2c");  
    $sql="UPDATE `cart` SET `quantity`=?,`status`=?,`total`=? WHERE `cartId`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("ssss",$quant,$status,$total,$cartid);
    $stmt->execute();
    if($stmt->affected_rows==1)
    {
      header('Location: usercart.php');
    }
  }
  if($status=="cart"){
    $conn=new mysqli("localhost","root","","f2c");  
    $sql="UPDATE `cart` SET `status`=? WHERE `cartId`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("ss",$status,$cartid);
    $stmt->execute();
    if($stmt->affected_rows==1)
    {
      header('Location: userwishlist.php');
    }
  }
}
else
{
 header('Location: userlogin.php');
}
?>