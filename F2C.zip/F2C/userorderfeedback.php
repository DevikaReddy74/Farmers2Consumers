<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  $orderid=$_GET['oid'];
	require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-12">
      <h1 class="center white"><u>Provide Feedback</u></h1><br/>
      <div class='row row-cols-4'>
<?php
  $conn=new mysqli("localhost","root","","f2c");

  $sql1="SELECT oi.`productId`, p.`productName`, p.`image` FROM `orderitems` oi JOIN `product` p ON oi.`productId`=p.`productId` JOIN `orders` o ON o.`orderId`=oi.`orderId` WHERE oi.`orderId`=? AND o.`userId`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$orderid,$userid);
  $stmt1->execute();
  $stmt1->bind_result($pid,$pname,$pimg);
  $empty=0; 
  while($stmt1->fetch())
  { 
    $empty=1;
    echo "
        <div class='col'>
          <div class='card' style='width: auto;'>
            <div class='card-body'>
              <form action='' method='post'>
                <table class='center'>
                  <tr>
                    <td>
                      <img src='".$pimg."' width='100%' alt='".$pname."' />
                      <br/>
                      <input type='checkbox' name='pid' value='".$pid."' checked/>
                      ".$pname."
                    </td>
                  </tr>
                  <tr>
                    <td>Rating &nbsp;&nbsp;&nbsp;
                      <input type='radio' name='rating' value='1' required/>
                      <input type='radio' name='rating' value='2' required/>
                      <input type='radio' name='rating' value='3' required/>
                      <input type='radio' name='rating' value='4' required/>
                      <input type='radio' name='rating' value='5' required/>
                    </td>
                  </tr>
                  <tr>
                    <td>
                    <textarea rows='2' cols='25' name='comment' required>
                    </textarea>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <button type='submit' name='uofs' class='btn btn-dark'>Submit</button>
                    </td>
                  </tr>
                </table>
              </form>
            </div>
          </div>
        </div>      
    ";
  }

  if(isset($_POST['uofs'])){
    $proid=$_POST['pid'];
    $rating=$_POST['rating'];
    $comment=$_POST['comment'];

    date_default_timezone_set("Asia/Calcutta");
    $date=date('d-m-Y H:i:s',time());

    $sql2="INSERT INTO `feedback`(`productId`, `userId`, `rating`, `comment`, `time`) VALUES (?,?,?,?,?)";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("sssss",$proid,$userid,$rating,$comment,$date);
    $stmt2->execute();
    if($stmt2->affected_rows==1)
    {
      echo "<script>window.alert('Thanks for Your Feedback');</script>";
    }
  }



?>


      </div>
    </div>
  </div>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
	header('Location: userlogin.php');
}
?>