<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <br/>
  <div class="row">
    <div class="col">
      <h1 class="center white"><u>Canceled Orders</u></h1>
      <br/>
<?php
  $status="Canceled";
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `orderId`, `userId`, `orderTotal`, `payment`, `status`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `status`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$status);
  $stmt->execute();
  $stmt->bind_result($orid,$uid,$ototl,$pay,$stat,$oron,$deon,$daddr);
  $a=0;
  $oid=array();
  $userid=array();
  $ototal=array();
  $payment=array();
  $ostatus=array();
  $oon=array();
  $delon=array();
  $addr=array();
  while($stmt->fetch())
  {
    $oid[$a]=$orid;
    $userid[$a]=$uid;
    $ototal[$a]=$ototl;
    $payment[$a]=$pay;
    $ostatus[$a]=$stat;
    $oon[$a]=$oron;
    $delon[$a]=$deon;
    $addr[$a]=$daddr;
    $a++;
  }
  echo "
			<div class='row row-cols-4'>";
  $ordered=0;
  for($i=0;$i<$a;$i++){

      $ordered=1;
      $orderid=$oid[$i];
      $conn=new mysqli("localhost","root","","f2c");
      $sql="SELECT oi.`productId`, p.`image`, p.`productName`, oi.`quantity`, oi.`price`, oi.`total` FROM `orderitems` oi JOIN `product` p ON p.`productId`=oi.`productId` WHERE oi.`orderId`=?";
      //$sql="SELECT o.`userId`,oi.`productId`,p.`image`,p.`productName`,oi.`quantity`,oi.`price`,oi.`total`,o.`orderOn`,o.`deliverOn`,o.`payment` FROM `orders` o JOIN `orderitems` oi ON oi.`orderId`=o.`orderId` JOIN `product` p ON p.`productId`=oi.`productId` WHERE o.`orderId`=? ORDER BY o.`orderOn` DESC";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("s",$orderid);
      $stmt->execute();
      $stmt->bind_result($pid,$img,$pname,$quant,$price,$total);
      echo "
			  <div class='col'>
  				<div class='card' style='width: auto;'>
	  				<div class='card-body'>
              <table class='center'>
		    		    <tr>
                  <td><b>Product</b></td>
                  <td><b>Quantity</b></td>
                  <td><b>*</b></td>
                  <td><b>Cost</b></td>
                  <td><b>=</b></td>
                  <td><b>Total</b></td>
                </tr>
	  	";
      while($stmt->fetch())
      {
        echo "	

									<td>
								  	<a href='adminviewproduct.php?pid=$pid'>".$pname."</a>
									</td>
                  <td>".$quant."</td>
                  <td>*</td>
                  <td>".$price."</td>
                  <td>=</td>
                  <td>".$total."</td>
								</tr>
			  ";  
      }
      echo "
                <tr>
                  <td colspan='6'>____________________</td>
                </tr>
                <tr>
                  <td colspan='5'><b>Total amount ₹ :</b></td>
                  <td>
                    <b>".$ototal[$i]."</b>
                  </td>
                </tr>";
      if($payment[$i]=='Not Paid'){
        echo "
                <tr>
                  <td colspan='6'><b>Pay On Delivery</b></td>
                </tr>
        ";
      }
      if($payment[$i]=='Paid'){
        echo "
                <tr>
                  <td colspan='6'>Paid</td>
                </tr>
        ";
      }

      echo "
                <tr>
                  <td colspan='6'><br/></td>
                </tr>
                <tr>
                  <td><b>Order On:</b></td>
                  <td colspan='5'>
                    ".$oon[$i]."
                  </td>
                </tr>                
              </table>
              <br/>
              <table>
                <tr>
                  <td colspan='2'><b>Address:</b></td>
                </tr>
                <tr>
                  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                  <td>
                    ".$addr[$i]."
                  </td>
                </tr>
                <tr>
                  <td colspan='2'><br/></td>
                </tr>
                <tr>
                  <td colspan='2' class='center'>
                    <h5></h5>
                  </td>
                </tr>
							</table>
              <table align='center'>
                <tr>
                  <td colspan='2'>
                    <a href='adminviewuser.php?uid=".$userid[$i]."'>
                      <button type='button' class='btn btn-dark'>View User</button>
                    </a> 
                    &nbsp;&nbsp;  
                  </td>
                </tr>
              </table>
				 	  </div>
	   			</div>
  			</div>
		  ";
  }
  echo "
      <div>
    </div>
  </div>";
  if($ordered==0)
  {
    echo "          
  <div class='row'>
    <div class='col-4'>
    </div>
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <br/><br/><br/>
        <h2 class='center'>Empty!...</h2>
        <br/><br/><br/>
      </div>
    </div>
    <div class='col-4'>
    </div>
  </div>";
  }
  
  echo "
  <br/>
</div>";

  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}

?>