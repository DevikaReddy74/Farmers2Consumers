<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col">
      <h1 class="white center"><u>Your Cart</u></h1>
      <div class='row row-cols-4'>
<?php

  $status="cart";
  //For displaying the cart items
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT c.`cartId`, c.`productId`, p.`image`, p.`productName`, p.`price`, c.`quantity`, c.`total`, p.`quantity` FROM `cart` c JOIN `product` p ON p.`productId`=c.`productId` WHERE c.`userId`=? AND c.`status`=? ORDER BY c.`cartId` DESC";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$userid,$status);
  $stmt1->execute();
  $stmt1->bind_result($cartid,$pid,$pro,$pname,$pcost,$quant,$total,$pquant);
  $a=0;
  $cost=0;
  //For using at the time of inserting items of an order
  $poid=array();
  $popro=array();
  $pocost=array();
  $i=0;
  while($stmt1->fetch())
  {
    $a=1;
    $change=0;
    if($quant>$pquant){
      $quant=$pquant;
      $total=$quant*$pcost;
      $change=1;
    }
    if($change==1){
      $conn=new mysqli("localhost","root","","f2c");
      $sql8="UPDATE `cart` SET `quantity`=?,`total`=? WHERE `cartId`=?";
      $stmt=$conn->prepare($sql8);
      $stmt->bind_param("sss",$quant,$total,$cartid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
      }
    }
    $popid[$i]=$pid;
    $popro[$i]=$pro;
    $popname[$i]=$pname;
    $pocost[$i]=$pcost;
    $poquant[$i]=$quant;
    $pototal[$i]=$total;
    $i++;
    echo "
        <div class='col'>
          <div class='card' style='width: auto;'>
            <div class='card-body'>
              <table>
		            <tr>
			            <td colspan='2'>
                    <a href='userviewitem.php?proid=$pid'>
                      <img src='".$pro."' height='50' width='50'/></td>
                    </a>
                  </td>
			          </tr>
		            <tr>
			            <td>
                    <a href='userviewitem.php?proid=$pid'>
                  
                  Product Name</a></td>
			            <td>
                    <a href='userviewitem.php?proid=$pid'>
                  
                  : ".$pname."</a></td>
                  </a>
			          </tr>
		            <tr>
			            <td>Cost Per KG</td>
			            <td>: ".$pcost."</td>
			          </tr>
		            <tr>
			            <td>Quantity</td>
			            <td>:
                    <a href='usercartquantitychange.php?pid=$pid&cid=$cartid&cquant=$quant&quant=dec'>
                      <input type='button' name='dec' value='-'/>
                    </a>
                    &nbsp;&nbsp;".$quant."&nbsp;&nbsp;
                    <a href='usercartquantitychange.php?pid=$pid&cid=$cartid&cquant=$quant&quant=inc'>
                      <input type='button' name='inc' value='+'/>
                    </a>
                  </td>
			          </tr>
		            <tr>
			            <td>Total</td>
			            <td>: ".$total."</td>
			          </tr>
		            <tr>
			            <td>
			              <a href='userdeletecart.php?cartid=$cartid'>
                      <button type='button' class='btn btn-dark'>Delete</button>
                    </a>
			            </td>
			            <td>
			              <a href='usercartstatuschange.php?cartid=$cartid&status=wish&cost=$pcost'>
                      <button type='button' class='btn btn-dark'>Add to Wishlist</button>
                    </a>
			            </td>
			          </tr>
		          </table>
	          </div>
          </div>
        </div>";
    //total cost of products that are ordered
    $cost=$cost+$total;
  }
 echo "
      </div>
    </div>
  </div>
  ";

  if($a==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>EMPTY...!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
  else{

?>   
  
  <br/>
  <br/>
  <br/>
  <div class="center">
    <button type="button" id="order" class="btn btn-dark">Order Now</button>
    <div id="div1"></div>
  </div>

  <!-- For Delivery address and payment option -->
  <script>
    document.getElementById("order").addEventListener("click",fun);
    function fun()
    {
      document.getElementById("div1").innerHTML='<br/><div class="row"><div class="col-4"></div><div class="col-4"><div class="card" style="width: auto;"><br/><form action="" method="post"><table><tr><td>Your Delivery Address is same as Your Address<br/>You can change the delivery address by going to your order at "My Orders" tab after placing an order.<br/>You can also pay online for your order at "My Orders" tab.</td></tr><tr><td><br/><b><input type="checkbox" name="pay" value="Not Paid" required/>&nbsp;&nbsp;&nbsp;&nbsp;Pay On Delivery</b></td></tr><tr><td><br/><button type="submit" name="sub" class="btn btn-dark">Place Order</button></td></tr></table></form><br/></div></div><div class="col-4"></div></div>';
    }    
  </script>


<?php

  }

  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `fullName`, `phoneNo`, `emailId` , `address`, `mandal` FROM `user` WHERE `userId`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$userid);
  $stmt->execute();
  $stmt->bind_result($nam,$ph,$mail,$add,$mandl);
  $name=0;
  $addr=0;
  $mandal=0;
  $phone=0;
  $userMail=0;
  while($stmt->fetch())
  {
    $name=$nam;
    $addr=$add;
    $mandal=$mandl;
    $phone=$ph;
    $userMail=$mail;

  }

  if(isset($_POST['sub']))
  {
    $update=0;
    $pay=$_POST['pay'];
    $address=$name.", ".$addr.", ".$phone;

    date_default_timezone_set("Asia/Calcutta");
    $date=date('d-m-Y H:i:s',time());

    $delon=date("d-m-Y",strtotime('tomorrow'));

    $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $mixedStr=str_shuffle($str);
    //$code=substr($mixedStr,0,6);
    $code="DEVIKA";
    //And then email this code to the user
  
    //For Delivery charge calculation
    $delcharge=0;
    $sql9="SELECT `deliveryBoyId` FROM `deliveryboy` WHERE `assignedTo`=?";
    $stmt9=$conn->prepare($sql9);
    $stmt9->bind_param("s",$mandal);
    $stmt9->execute();
    $stmt9->bind_result($delboyid);       
    while($stmt9->fetch())
    {
      switch($mandal){
        case 'Anantapur' : $delcharge=20;
                            break;
        case 'Bathalapalli' : $delcharge=37;
                            break;
        case 'Chennekothapalli' : $delcharge=60;
                            break;        
        case 'Dharmavaram' : $delcharge=52;
                            break;        
        case 'Garladinne' : $delcharge=29;
                            break;        
        case 'Kanagaanapalli' : $delcharge=54;
                            break;        
        case 'Narpala' : $delcharge=36;
                            break;        
        case 'Pamidi' : $delcharge=45;
                            break;        
        case 'Raptadu' : $delcharge=21;
                            break;        
        case 'Tadimarri' : $delcharge=49;
                            break; 
        default : echo "Something Wrong";                         

      }
    }
    //order products cost + delivery charge calculation
    $totalpay=$cost+$delcharge;

    // for inserting order details
    $sql3="INSERT INTO `orders`(`userId`, `deliveryBoyId`, `orderTotal`, `deliveryCharge`, `totalPay`, `payment`, `orderOn`, `deliverOn`, `deliveryCode`, `deliveryAddress`) VALUES (?,?,?,?,?,?,?,?,?,?)";
    $stmt3=$conn->prepare($sql3);
    $stmt3->bind_param("ssssssssss",$userid,$delboyid,$cost,$delcharge,$totalpay,$pay,$date,$delon,$code,$address);
    $stmt3->execute();
    $order=0;
    if($stmt3->affected_rows>0)
    {
      $order=1;
      echo "<script>window.alert('Items Ordered Successfully');</script>";
    }   
    $orderi=0; 
    if($order==1){
      
      // for retreiving the order id for inserting order items
      $sql4="SELECT `orderId` FROM `orders` WHERE `userId`=? ORDER BY `orderId` DESC LIMIT 1";
      $stmt4=$conn->prepare($sql4);
      $stmt4->bind_param("s",$userid);
      $stmt4->execute();
      $stmt4->bind_result($oid);
           
      while($stmt4->fetch())
      {
        $orderi=1;
      }
    }
    if($orderi==1){
      for($j=0;$j<$i;$j++){
        //Inserting order items
        $sql5="INSERT INTO `orderitems`(`orderId`, `productId`, `quantity`, `price`, `total`) VALUES (?,?,?,?,?)";
        $stmt5=$conn->prepare($sql5);
        $stmt5->bind_param("sssss",$oid,$popid[$j],$poquant[$j],$pocost[$j],$pototal[$j]);
        $stmt5->execute();
        if($stmt5->affected_rows>0)
        {
          $ppid=$popid[$j];
          //selecting original quantity of a product for changing
          $sql6="SELECT `quantity` FROM `product` WHERE `productId`=?";
          $stmt6=$conn->prepare($sql6);
          $stmt6->bind_param("s",$ppid);
          $stmt6->execute();
          $stmt6->bind_result($oriquant); 
          $updquant=0;     
          while($stmt6->fetch())
          { 
            $updquant=$oriquant-$poquant[$j];
          }
          if($updquant!=0){
            //Changing the original quantity of a product after ordering this product
            $sql7="UPDATE `product` SET `quantity`=? WHERE `productId`=?"; 
            $stmt7=$conn->prepare($sql7);
            $stmt7->bind_param("ss",$updquant,$ppid);
            $stmt7->execute();
            
            if($stmt7->affected_rows==1)
            {
              $update=1;

            }
            

          }
        }
      }
    }
    if($update==1 && !empty($userMail)){
      echo "<script>window.alert('Delivery Code sent to your Mail Id');</script>";
      //This is for mail the delivery code to a user for the purpous of delivery
        /* Mailing working online
        $sub="Delivery code for your Order";
        $msg="Dear ".$name." <br/> Use this code ".$code." at the time of delivry</br>Thank you";
        $fromMail="From:devikadvks77@gmail.com \r\n";
        $res=mail($userMail,$sub,$msg,$fromMail);
        if($res){
          echo "<script>window.alert('Delivery Code sent to your Mail Id');</script>";
        }
        else{
          echo "Error";
        }
        */
    }
  }
?>
    </div>
  </div>
</div>


<?php
  require_once('backgroundfoot.php');
}
else
{
 header('Location: userlogin.php');
}
?>