<?php
session_start();
if(!empty($_SESSION['admin']))
{
 require_once('backgroundhead.php');
 require_once('adminmenubar.php');
?>

<div class="alert alert-primary">
  <div class="row">
    <div class="col-8">
<?php
 $farmerid=$_SESSION['admin'];
 $conn=new mysqli("localhost","root","","f2c");
 $stmt=$conn->prepare(" SELECT `Orderid`, `Userid`, `Productid`, `Product`, `Productname`, `Quantity`, `CostPerKG`, `Total`, `Payment` FROM `orders` WHERE `Farmerid`=?");
 $stmt->bind_param("s",$farmerid);
 $stmt->execute();
 $stmt->bind_result($oid,$userid,$pid,$pro,$pname,$quant,$cost,$total,$pay);
 echo "<div class='row row-cols-2'>";
 $a=0;
 $i=0;
 while($stmt->fetch())
 {
   $a=1;
   $poid[$i]=$oid;
   $puserid[$i]=$userid;
   $ppid[$i]=$pid;
   $ppro[$i]=$pro;
   $ppname[$i]=$pname;
   $pquant[$i]=$quant;
   $pcost[$i]=$cost;
   $ptotal[$i]=$total;
   $ppay[$i]=$pay;
   $i=$i+1;
 }
 $p=0;
 $k=0;
 for($j=0;$j<$i;$j++)
 {
     echo "<div class='col'>
     <div class='card' style='width: 20rem;'>
      <div class='card-body'>
       <table border='0' align='center'>
         <tr>
		   <td colspan='2'><h3>".$poid[$j]."</h3></td>
		 </tr>
		 <tr>
		   <td colspan='2'><a href='adminvieworders.php?addr=$puserid[$j]'>Address</a></td>
		 </tr>
         <tr>
		   <td colspan='2'><br/></td>
		 </tr>
         <tr>
		   <td>Product</td>
		   <td><img src='".$ppro[$j]."' height='50' width='50'/></td>
		 </tr>
         <tr>
		   <td>Product Name</td>
		   <td>".$ppname[$j]."</td>
		 </tr>
         <tr>
		   <td>Quantity</td>
		   <td>".$pquant[$j]."</td>
		 </tr>
         <tr>
		   <td>Cost</td>
		   <td>".$pcost[$j]."</td>
		 </tr>
         <tr>
		   <td>Total</td>
		   <td>".$ptotal[$j]."</td>
		 </tr>*
         <tr>
		   <td>Payment</td>
		   <td>".$ppay[$j]."</td>
		 </tr>
	   </table>";

      for($k=$j+1;$k<$i;$k++)
      {
	    if($poid[$j]==$poid[$k])
	    {
		  echo "
          <table border='0' align='center'>
           <tr>
		    <td colspan='2'><br/></td>
		   </tr>
           <tr>
		    <td colspan='2'><br/></td>
		   </tr>
           <tr>
		    <td>Product</td>
		    <td><img src='".$ppro[$k]."' height='50' width='50'/></td>
		   </tr>
           <tr>
		    <td>Product Name</td>
		    <td>".$ppname[$k]."</td>
		   </tr>
           <tr>
		    <td>Quantity</td>
		    <td>".$pquant[$k]."</td>
		   </tr>
           <tr>
		    <td>Cost</td>
		    <td>".$pcost[$k]."</td>
		   </tr>
           <tr>
		    <td>Total</td>
		    <td>".$ptotal[$k]."</td>
		   </tr>
           <tr>
		    <td>Payment</td>
		    <td>".$ppay[$k]."</td>
		   </tr>
	      </table>";
	    }
      }
	 echo "
	   </div>
	 </div>
	</div>";

 }

 if($a==0)
 {
  echo "<h2>EMPTY!.....</h2>";
 }

?>
    </div>
	</div>
    <div class="col-4">
    <h3><u>Address of </u></h3>
<?php
 if(!empty($_GET['addr']))
 {
  $auserid=$_GET['addr'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("SELECT `Fullname`, `Phoneno`, `Emailid`, `Address` FROM `userregister` WHERE `Userid` = ? ");
  $stmt->bind_param("s",$auserid);
  $stmt->execute();
  $stmt->bind_result($fname,$phone,$mail,$addr);
  $b=0;
  while($stmt->fetch())
  {
   $b=1;
  }
  if($b==1)
  {
   echo "
    <h3 align='center'>
     <u>".$fname."</u>
    </h3>
    <table border='1' align='center'>
    <tr>
     <td>Name</td>
     <td>".$fname."</td>
    </tr>
    <tr>
     <td>Phone no</td>
     <td>".$phone."</td>
    </tr>
    <tr>
     <td>Mail id</td>
     <td>".$mail."</td>
    </tr>
    <tr>
     <td>Address</td>
     <td>".$addr."</td>
    </tr>
   </table>";
  }
 }
?>
     </div>
	</div>
  
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>