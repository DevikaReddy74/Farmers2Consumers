<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
	require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-4">
	  </div>
    <div class="col-4">	
	    <div class="card" style="width: auto;">
        <div class="card-body">
          <form action="" method="post" align="center" enctype="multipart/form-data" >
            <table align="center">
              <tr>
                <td colspan="2">
                  <u><h1>Add Delivery Boy </h1></u>
                </td>
              </tr>
              <tr>
                <td>Full Name</td>
                <td>
                  <input type="text" name="fname" maxlength="15" required/>
                </td>
              </tr>

          <tr>
            <td>Gender</td>
            <td>
              <input type="radio" name="ge" value="Male" required/>
              Male
              <input type="radio" name="ge" value="Female" required/>
              Female
            </td>
          </tr> 
              <tr>
                <td>Photo</td>
                <td>
                  <input type="file" name="pfile" required/>
                </td>
              </tr>
          <tr>
            <td>Date of Birth</td>
            <td>
              <input type="date" name="dob" required/>
            </td>
          </tr>
          <tr>
            <td>Phone No</td>
            <td><input type="text" name="ph" maxlength="10" required/>
            </td>
          </tr>
          <tr>
            <td>Email</td>
            <td>
              <input type="text" name="ma" maxlength="30" required/>
            </td>
          </tr>
          <tr>
            <td>Door No.</td>
            <td>
              <input type="text" name="dno" required/>
            </td>
          </tr>
          <tr>
            <td>Address Line</td>
            <td>
              <input type="text" name="addrline" required/>
            </td>
          </tr>          
          <tr>
            <td>Mandal</td>
            <td>
              <select name="mandal">
<?php
require_once('mandals.php');
?>
              </select>     
            </td>
          </tr>
          <tr>
            <td>District</td>
            <td>
              <select name="dist">
                <option>Anantapur</option>
              </select>     
            </td>
          </tr>
          <tr>
            <td>Pincode</td>
            <td>
              <input type="text" name="pincode" required/>
            </td>
          </tr>
          <tr>
            <td>Assigned To</td>
            <td>
              <select name="ato">
<?php
require_once('deliveryplaces.php');
?>
              </select>     
            </td>
          </tr>
              <tr>
                <td colspan="2">
                  <button type="submit" name="aadbs" class="btn btn-dark">Submit</button>
                </td>
              </tr>
            </table>
          </form>
	      </div>
	    </div>
    </div>
    <div class="col-4">
    </div>
  </div>
</div>
                            
<?php
  if(isset($_POST['aadbs']))
  {
	  $fname=$_FILES['pfile']['name'];
	  $ftemp=$_FILES['pfile']['tmp_name'];//default storage of images
	  $ferr=$_FILES['pfile']['error'];
	  if($ferr==0)
	  {
	  	date_default_timezone_set("Asia/Calcutta");//timezone
      $fname=date('dmYHis',time());// date and time
		  $fdest="./images/".$fname;
		  move_uploaded_file($ftemp,$fdest);//source, destination

      date_default_timezone_set("Asia/Calcutta");
      $date=date('d-m-Y H:i:s',time());

      $fname=$_POST['fname'];
      $ge=$_POST['ge'];
      $dob=$_POST['dob'];
      $ph=$_POST['ph'];
      $dmail=$_POST['ma'];
      $addr=$_POST['dno']."<br/>".$_POST['addrline']."<br/>".$_POST['mandal'].", ".$_POST['dist']."<br/>".$_POST['pincode'];
      $ato=$_POST['ato'];

      $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      $mixedStr=str_shuffle($str);
  
      //$pass=substr($mixedStr,0,6);
      $pass="adevika";

      /* Mailing working online
      $sub="Password for login";
      $msg="Dear ".$fname." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
      $fromMail="From:devikadvks77@gmail.com \r\n";
      $res=mail($dmail,$sub,$msg,$fromMail);
      if($res){
        echo "Message sent";
      }
      else{
        echo "Error";
      }
      */


      $pr=password_hash($pass,PASSWORD_DEFAULT);
      
      $conn=new mysqli("localhost","root","","f2c");
      $sql="INSERT INTO `deliveryboy`(`fullName`, `image`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `assignedTo`, `registerDate`, `password`) VALUES (?,?,?,?,?,?,?,?,?,?)";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("ssssssssss",$fname,$fdest,$ge,$dob,$ph,$dmail,$addr,$ato,$date,$pr);
      $stmt->execute();
      if($stmt->affected_rows>0)
      {
			  echo "<script>window.alert('Detailes Added successfully');</script>";
      }
      else
      {
        echo "<script>window.alert('Not Added');</script>";
      }
	  }
	  else
	  {
		  echo "<script>window.alert('Error while uploading the file');</script>";
	  }
  }

  require_once('backgroundfoot.php');
}
else
{
	header('Location: adminlogin.php');
}
?>