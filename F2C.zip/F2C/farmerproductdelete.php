<?php
session_start();
if(!empty($_SESSION['farmer']))
{
  $pro=$_GET['proid'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `products` WHERE `Productid` = ? ");
  $stmt->bind_param("s",$pro);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
   echo "<script>window.alert('Item Deleted successfully');</script>";
  }
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `cart` WHERE `Productid` = ? ");
  $stmt->bind_param("s",$pro);
  $stmt->execute();
  if($stmt->affected_rows)
  {
   echo "<script>
            window.alert('Item Deleted from cart successfully');
         </script>";
  }
  header('Location: farmerhome.php');
}
else
{
  header('Location: farmerlogin.php');
}
?>