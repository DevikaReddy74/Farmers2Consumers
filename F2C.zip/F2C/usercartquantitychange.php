<?php
session_start();
if(!empty($_SESSION['user']))
{
  $proid=$_GET['pid'];
  $cartid=$_GET['cid'];
  $change=$_GET['quant'];
  $cquant=$_GET['cquant'];

  $a=0;
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `price`,`quantity` FROM `product` WHERE `productId`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("s",$proid);
  $stmt1->execute();
  $stmt1->bind_result($price,$pquant);
  while($stmt1->fetch())
  {
    $a=1;
  }
  if($a==1){
    if($change=="inc" && $cquant<$pquant){
      $quant=$cquant+1;
      $total=$quant*$price;
      $conn=new mysqli("localhost","root","","f2c");  
      $sql="UPDATE `cart` SET `quantity`=?,`total`=? WHERE `cartId`=?";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("sss",$quant,$total,$cartid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
        header('Location: usercart.php');
      }
      else {
        header('Location: usercart.php');
      }    
    } 
    else if($change=="dec" && $cquant>1){
      $quant=$cquant-1;
      $total=$quant*$price;
      $conn=new mysqli("localhost","root","","f2c");  
      $sql="UPDATE `cart` SET `quantity`=?,`total`=? WHERE `cartId`=?";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("sss",$quant,$total,$cartid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
        header('Location: usercart.php');
      }
      else {
        header('Location: usercart.php');
      } 
    }
    else {
      header('Location: usercart.php');
    } 
  }
}
else
{
 header('Location: userlogin.php');
}
?>