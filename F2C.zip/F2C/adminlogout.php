<?php
session_start();
if(!empty($_SESSION['admin']))
{
	unset($_SESSION['admin']);
	unset($_SESSION['id']);
    header('Location: adminlogin.php');
}
else
{
    header('Location: adminlogin.php');
}
?>