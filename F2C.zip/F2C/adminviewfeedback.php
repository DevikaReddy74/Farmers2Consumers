<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
  $proid=$_GET['proid'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-2 center">
    </div>
    <div class="col-8 center">
      <div class="card" style="width: auto;">
        <div class="card-body">
          <h1 class="center"><u>Product Rating</u></h1><br/>
          <table border="1" align="center">
            <tr>
              <th>&nbsp;&nbsp;Name&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Rating&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Comment&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;Time&nbsp;&nbsp;</th>
            </tr>

<?php
  //For displaying product
  $conn=new mysqli("localhost","root","","f2c");
  $sql5="SELECT u.`fullName`, f.`rating`, f.`comment`, f.`time` FROM `feedback` f JOIN `user` u ON  u.`userId`=f.`userId` WHERE `productId`=? ORDER BY f.`feedbackId` DESC";
  $stmt5=$conn->prepare($sql5);
  $stmt5->bind_param("s",$proid);
  $stmt5->execute();
  $stmt5->bind_result($fname,$rating,$comment,$time);
  $rate=0;
  $count=0;
  while($stmt5->fetch()){
    $count++;
    echo "
            <tr>
              <td>&nbsp;".$fname."&nbsp;</td>
              <td>".$rating."</td>
              <td>&nbsp;".$comment."&nbsp;</td>
              <td>&nbsp;".$time."&nbsp;</td>
            </tr>
    ";
    $rate+=$rating;
  }
  if($count==0){
      echo "         <tr>
              <td colspan='4'><h1>No Comments Yet</h1></td>
            </tr>";
  }
  else{
    $avgrate=$rate/$count;
    echo "         <tr>
              <td colspan='4'><h1>⭐ ".round($avgrate,1)."</h1></td>
            </tr>";
  }
?>
          </table>
        </div>
      </div>
    </div>
    <div class="col-2">
    </div>
  </div>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>