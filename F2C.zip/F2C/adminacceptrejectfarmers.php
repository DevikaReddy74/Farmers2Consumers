<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
        <div class='card' style='width: auto;'>
	  			<div class='card-body'>
          <br/><h1 class="center"><u>Farmer Requests</u></h1><br/>

      <table border="1" align="center">
         <tr>
           <th>&nbsp;&nbsp;S.No&nbsp;&nbsp;</th>
           <th>&nbsp;Picture&nbsp;</th>
           <th>&nbsp;&nbsp;Name&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Gender&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;DOB&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Contact&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Email&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Address&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Accept&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Delete&nbsp;&nbsp;</th>
         </tr>
<?php
  $data=0;
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `farmerId`, `image`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `registerDate`, `updateOn` FROM `farmer` WHERE `password`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$data);
  $stmt->execute();
  $stmt->bind_result($farmerid,$img,$fname,$gen,$dob,$phone,$mail,$addr,$regdate,$update);
  $a=0;
  $i=1;
  while($stmt->fetch())
  {
    $a=1;
    echo "  <tr>
          <td>&nbsp;&nbsp;".$i."&nbsp;&nbsp;</td>
          <td>&nbsp;<img src='".$img."' height='50%' width='80' alt='image'/>&nbsp;</td>
          <td>&nbsp;".$fname."&nbsp;</td>
          <td>&nbsp;".$gen."&nbsp;</td>
          <td>&nbsp;".$dob."&nbsp;</td>
          <td>&nbsp;".$phone."&nbsp;</td>
          <td>&nbsp;".$mail."&nbsp;</td>
          <td>".$addr."</td>
          <td>&nbsp;<a href='adminacceptfarmers.php?fida=$farmerid&data=accept'>
          <button type='button' class='btn btn-dark'>Accept</button></a>&nbsp;</td>
          <td>&nbsp;<a href='adminacceptfarmers.php?fidd=$farmerid&data=reject'>
          <button type='button' class='btn btn-dark'>Reject</button></a>&nbsp;</td>
         </tr>";
    $i++;
  }
  if($a==0)
  {
    echo " <tr>
          <td colspan='10'>
            <h1 align='center'>Empty!<h1/>
          </td>
         </tr>";
  }
  if(!empty($_GET['fidd']))
  {
    $farmer=$_GET['fidd'];
    $conn=new mysqli("localhost","root","","f2c");
    $stmt=$conn->prepare("DELETE FROM `farmer` WHERE `farmerId` = ? ");
    $stmt->bind_param("s",$farmer);
    $stmt->execute();
    if($stmt->affected_rows>0)
    {
      /* Mailing working online
      $sub="Password for login";
      $msg="Dear ".$fn." <br/> Your registration in farmers2Consumers app is rejected.";
      $fromMail="From:devikadvks77@gmail.com \r\n";
      $res=mail($userMail,$sub,$msg,$fromMail);
      if($res){
        echo "Message sent";
      }
      else{
        echo "Error";
      }
      */
      echo "
      <script>
        window.alert('Farmer Deleted successfully');
      </script>";      
    }
    else
    {
      echo "<script>window.alert('Farmer Not Deleted');</script>";
    }
  }
  if(!empty($_GET['fida']))
  {
    $user=$_GET['fida'];

    $str='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $mixedStr=str_shuffle($str);
  
    //$pass=substr($mixedStr,0,6);
    $pass="adevika";

    /* Mailing working online
    $sub="Password for login";
    $msg="Dear ".$fn." <br/> Use this Password ".$pass." for login into the system</br> Do not share this password";
    $fromMail="From:devikadvks77@gmail.com \r\n";
    $res=mail($userMail,$sub,$msg,$fromMail);
    if($res){
      echo "Message sent";
    }
    else{
      echo "Error";
    }
    */


    $pr=password_hash($pass,PASSWORD_DEFAULT);

    $conn=new mysqli("localhost","root","","f2c");
    $sql2="UPDATE `farmer` SET `password`=? WHERE `farmerId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("ss",$pr,$farmer);
    $stmt2->execute();
    if($stmt2->affected_rows>0)
    {
    echo "
      <script>
        window.alert('Accepted successfully');
      </script>";
    }
    else
    {
      echo "<script>window.alert('Something Wrong');</script>";
    }

  }
?>
      </table>
      <br/>
    </div>
    <div class="col-1">
    </div>
  </div>
  <br/>
  <br/>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}
?>