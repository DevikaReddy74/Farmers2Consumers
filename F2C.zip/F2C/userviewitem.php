<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  $proid=$_GET['proid'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-2">
    </div>
    <div class="col-4 center">
<?php
  //For displaying product
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `productName`, `image`, `price`, `quantity`, `description`, `category`, `type` FROM `product` WHERE `productId`=?";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("s",$proid);
  $stmt1->execute();
  $stmt1->bind_result($pname,$product,$pprice,$quant,$des,$cat,$type);
  while($stmt1->fetch()){
  echo '
      <div class="card" style="width: auto;">
        <img class="card-img-top" src="'.$product.'" alt="'.$pname.'">
        <div class="card-body">
          <h3>'.$pname.'<br/>Price ₹: '.$pprice.' /KG
          <br/>Available Quantity: '.$quant.' KGs
          <br/>'.$des.'</h3>
        </div>
      </div><br/><br/>';
  }
 echo '
      <form action="" method="post" class="center">
        <input type="submit" name="cart" value="Add to Cart"/>
      </form>';
  if(isset($_POST['cart']))
  {
    //To verify that the item is already in the cart or not
    $conn=new mysqli("localhost","root","","f2c");
    $sql3="SELECT `cartId`, `status` FROM `cart` WHERE `userId`=? AND `productId`=?";
    $stmt3=$conn->prepare($sql3);
    $stmt3->bind_param("ss",$userid,$proid);
    $stmt3->execute();
    $stmt3->bind_result($cartid,$status);
    $a=0;
    while($stmt3->fetch())
    {
      $a=1;
    }
    if($a==0){
      //if the item is not in the cart then adding it into the cart
      $conn=new mysqli("localhost","root","","f2c");
      $sql2="INSERT INTO `cart`(`userId`, `productId`, `total`) VALUES (?,?,?)";
      $stmt2=$conn->prepare($sql2);
      $stmt2->bind_param("sss",$userid,$proid,$pprice);
      $stmt2->execute();
      if($stmt2->affected_rows>0)
      {
		    echo "<script>window.alert('Item Added to the cart successfully');</script>";
      }
      else
      {
		    echo "<script>window.alert('Item is not Added to the cart');</script>";
      }
    }
    else if($a==1 && $status=="cart"){
      //if item is already in the cart
		  echo "<script>window.alert('Item is already in the cart');</script>";
    }
    else{
      $status="cart";
      //If the item is in the wish list then adding to cart
      $conn=new mysqli("localhost","root","","f2c");  
      $sql4="UPDATE `cart` SET `status`=? WHERE `cartId`=?";
      $stmt=$conn->prepare($sql4);
      $stmt->bind_param("ss",$status,$cartid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
		    echo "<script>window.alert('Item Added to the cart successfully');</script>";
      }
    }
  } 
?>    
    </div>
    <div class="col-4 center">
      <div class="card" style="width: auto;">
        <div class="card-body">
          <h1 class="center"><u>Product Rating</u></h1><br/>
          <table border="1" align="center">
            <tr>
              <th>Name</th>
              <th>Rating</th>
              <th>Comment</th>
              <th>Time</th>
            </tr>

<?php
  //For displaying product
  $conn=new mysqli("localhost","root","","f2c");
  $sql5="SELECT u.`fullName`, f.`rating`, f.`comment`, f.`time` FROM `feedback` f JOIN `user` u ON  u.`userId`=f.`userId` WHERE `productId`=?";
  $stmt5=$conn->prepare($sql5);
  $stmt5->bind_param("s",$proid);
  $stmt5->execute();
  $stmt5->bind_result($fname,$rating,$comment,$time);
  $rate=0;
  $count=0;
  while($stmt5->fetch()){
    $count++;
    echo "
            <tr>
              <td>&nbsp;".$fname."&nbsp;</td>
              <td>".$rating."</td>
              <td>".$comment."</td>
              <td>".$time."</td>
            </tr>
    ";
    $rate+=$rating;
  }
  if($count==0){
      echo "         <tr>
              <td colspan='4'><h1>No Comments Yet</h1></td>
            </tr>";
  }
  else{
    $avgrate=$rate/$count;
    $avg=round($avgrate,1);
    echo "         <tr>
              <td colspan='4'><h1>⭐ ".$avg."</h1></td>
            </tr>";
  }
?>
          </table>
        </div>
      </div>
    </div>
    <div class="col-2">
    </div>
  </div>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: userlogin.php');
}
?>