<?php
session_start();
require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<br/>
<div class="alert">
  <div class="row">
    <div class="col-1">
	  </div>
    <div class="col-10">	
	    <div class="card" style="width: auto;">
        <div class="card-body">
          <h1 class="center"><u>Terms & Conditions</u></h1>
          

        </div>
        <br/>
      </div>
    </div>
    <div class="col-1">
	  </div>
  </div>
</div>


<?php
require_once('backgroundfoot.php');
?>