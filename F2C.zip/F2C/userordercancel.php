<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  if(!empty($_GET['oid']))
  {
	  $oid=$_GET['oid'];
    $stat="Canceled";
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="UPDATE `orders` SET `status`=? WHERE `orderId`=?";
    $stmt1=$conn->prepare($sql1);
    $stmt1->bind_param("ss",$stat,$oid);
    $stmt1->execute();
    $cancel=0;
    if($stmt1->affected_rows>0)
    {
      $cancel=1;
    }
	  else
    {
	    echo "<script>window.alert('Try again after sometime');</script>";
    }
    $ordercancel=0;
    if($cancel==1){
      $sql2="SELECT oi.`productId`, oi.`quantity`, p.`quantity` FROM `orderitems` oi JOIN `product` p ON p.`productId`=oi.`productId` WHERE oi.`orderId`=?";
      $stmt2=$conn->prepare($sql2);
      $stmt2->bind_param("s",$oid);
      $stmt2->execute();
      $stmt2->bind_result($pid,$orderquant,$originalquant);
      $u=0;
      $proid=array();
      $updquant=array(); 
      while($stmt2->fetch())
      { 
        $proid[$u]=$pid;
        $ordquant[$u]=$originalquant;
        $orgquant[$u]=$orderquant;
        $u++;
      }
      for($i=0;$i<$u;$i++){
        $uquant=$ordquant[$i]+$orgquant[$i];
        $prid=$proid[$i];
        $sql3="UPDATE `product` SET `quantity`=? WHERE `productId`=?";
        $stmt3=$conn->prepare($sql3);
        $stmt3->bind_param("ss",$uquant,$prid);
        $stmt3->execute();

        if($stmt1->affected_rows>0)
        {
          $ordercancel=1;
        }
      }
          
    }
    $back=0;
    if($ordercancel==1){
      $back=1;
      echo "<script>window.alert('Order Canceled Successfully');</script>";
    }
    if($back==1){
      header('Location: userorders.php');
    }

  }
}
else
{
  header('Location: userlogin.php');
}
?>