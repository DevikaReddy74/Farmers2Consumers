<?php

if(!empty($_POST['pname']) && !empty($_FILES['pfile']) && !empty($_POST['pprice']) && !empty($_POST['psdes']))
{
	$fname=$_FILES['pfile']['name'];
	$ftemp=$_FILES['pfile']['tmp_name'];
	$ferr=$_FILES['pfile']['error'];
	if($ferr==0)
	{
		$fdest="./images/".$fname;
		move_uploaded_file($ftemp,$fdest);
		$name=$_POST['pname'];
        $price=$_POST['pprice'];
        $sdes=$_POST['psdes'];
        $conn=new mysqli("localhost","root","","f2c");
        $stmt=$conn->prepare("UPDATE `products` SET `Productname`=?,`Productview`=?,`Productprice`=?,`Shortdes`=? WHERE `Productid`=$pro");
        $stmt->bind_param("ssss",$name,$fdest,$price,$sdes);
        $stmt->execute();
        if($stmt->affected_rows==1)
        {
			echo "<br/><h2>Item Updated successfully</h2>";    
        }
        else
        {
			echo "<br/><h2>Item is not Updated</h2>";
        }
	}
}
?>