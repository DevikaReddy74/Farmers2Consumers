<option>Banana</option>
<option>Beans</option>
<option>Beetroot</option>
<option>Bitter Gourd</option>
<option>Brinjal</option>
<option>Cabbage</option>
<option>Capsicum</option>
<option>Carrot</option>
<option>Chilli</option>
<option>Cluster Beans</option>
<option>Custard Apple</option>
<option>Garlic</option>
<option>Grapes</option>
<option>Guava</option>
<option>Ladys Finger</option>
<option>Mango</option>
<option>Onion</option>
<option>Papaya</option>
<option>Potato</option>
<option>Radish</option>
<option>Sweet Potato</option>
<option>Tamarind</option>
<option>Tomato</option>
<option>Watermelon</option>