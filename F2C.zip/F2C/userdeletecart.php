<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  $cartid=$_GET['cartid'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `cart` WHERE `Cartid`=?");
  $stmt->bind_param("s",$cartid);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
    echo "<script>window.alert('Item Deleted successfully');</script>";
  }
  header('Location: usercart.php');
}
else
{
 header('Location: userlogin.php');
}
?>