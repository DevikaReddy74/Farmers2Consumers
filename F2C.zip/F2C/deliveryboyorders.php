<?php
session_start();
if(!empty($_SESSION['deliveryboy']))
{
  $boy=$_SESSION['deliveryboy'];
  require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<div class="alert">
  <br/>
  <div class="row">
    <div class="col-9">
    </div>
    <div class="col-2">
      <a href="deliveryboychangepassword.php">
        <button type="button" class="btn btn-primary">Change Password</button>
      </a>
</div>
    <div class="col-1">

      <a href="deliveryboylogout.php">
        <button type="button" class="btn btn-primary">Logout</button>
      </a>
    </div>
  </div>
  <br/>
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
      <div class='card' style='width: auto;'>
				<div class='card-body'>
          <h1 class="center"><u>Orders</u></h1>
          <table class='center' border='1' align='center'>
		  	    <tr>
              <th>&nbsp;&nbsp;&nbsp;ID No&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Address&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Amount&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Payment&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Delivered&nbsp;&nbsp;&nbsp;</th>
            </tr>
<?php
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `orderId`, `userId`, `totalPay`, `payment`, `status`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `status`=? AND `deliveryBoyId`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("ss",$status,$boy);
  $stmt->execute();
  $stmt->bind_result($orid,$uid,$total,$pay,$stat,$oon,$delon,$addr);
  $a=0;
  while($stmt->fetch())
  {
    $a++;
    echo "
              <tr>
                <td>".$orid."</td>
                <td>".$addr."</td>
                <td>".$total."</td>
                <td>".$pay."</td>
                <td>
                  <a href='deliveryboyproductdelivered.php?orid=$orid'>
                    <button type='button' name='delivery' class='btn btn-dark'>Delivered
                    </button>
                  </a>
                </td>
              </tr>
		  ";
    }

  if($a==0)
  {
    echo "          
          <tr>
            <td colspan='5'><br/><h1>Empty</h1><br/></td>      
          </tr>";
  }
  echo "
            </table>
      <div>
    </div>
  </div> 
  <br/>
</div>";

  require_once('backgroundfoot.php');
}
else
{
  header('Location: deliveryboylogin.php');
}

?>