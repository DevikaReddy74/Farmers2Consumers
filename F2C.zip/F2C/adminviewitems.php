<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-12">
      <div class='row row-cols-4'>
<?php
  $protype=$_POST['itemtype'];
  $type=$_POST['type'];
  $conn=new mysqli("localhost","root","","f2c");
  if($type=="my"){
    $sql="SELECT `productId`, `productName`, `image`, `price`, `quantity`, `description`, `category`, `type`, `available` FROM `product` WHERE `type`=? AND `farmerId`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("ss",$protype,$farmer);
    $stmt->execute();
    $stmt->bind_result($pid,$pname,$product,$pprice,$pquant,$pdes,$pcat,$ptype,$avail);
  }
  else if($type=="all"){
    $sql="SELECT `productId`, `productName`, `image`, `price`, `quantity`, `description`, `category`, `type`, `available` FROM `product` WHERE `type`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s",$protype);
    $stmt->execute();
    $stmt->bind_result($pid,$pname,$product,$pprice,$pquant,$pdes,$pcat,$ptype,$avail);
  }
  $a=0;
  $pids=array();
  $pnames=array();
  $products=array();
  $pprices=array();
  $pquants=array();
  $pdess=array();
  $pcats=array();
  $ptypes=array();
  $avails=array();
  while($stmt->fetch())
  {
    $pids[$a]=$pid;
    $pnames[$a]=$pname;
    $products[$a]=$product;
    $pprices[$a]=$pprice;
    $pquants[$a]=$pquant;
    $pdess[$a]=$pdes;
    $pcats[$a]=$pcat;
    $ptypes[$a]=$ptype;
    $avails[$a]=$avail;

    $a++;
  }
  for($i=0;$i<$a;$i++)
  {
    $proid=$pids[$i];
    $rating=0;
    $sql2="SELECT avg(`rating`) FROM `feedback` WHERE `productId`=?";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("s",$proid);
    $stmt2->execute();
    $stmt2->bind_result($ratings);
    $c=0;
    while($stmt2->fetch())
    {
      $rating=round($ratings,1);
    }
	  echo "	
        <div class='col'>
	        <div class='card' style='width: auto;'>
            <img class='card-img-top' src='".$products[$i]."' alt='".$pnames[$i]."' height='200'>
            <center>";
    if($type=='my'){
    echo "
    		      <a href='adminproductedit.php?proid=$proid&edit=img'>
                <button type='button' name='button' class='btn btn-dark'>Change Image
                </button>
              </a>";
    }
    echo "
            <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;⭐ ".$rating."</b>
              
            <div class='card-body'>
	            <table align='center'>
		            <tr>
		              <td>ID</td>
          			  <td>: ".$proid."</td>
		            </tr>
                <tr>
		              <td>Name</td>
          			  <td>: ".$pnames[$i]."</td>
		            </tr>		 
		            <tr>
		              <td>Price ₹ </td>
			            <td>: ".$pprices[$i]." /KG</td>
		            </tr>		 
		            <tr>
		              <td>Available</td>
			            <td>: ".$pquants[$i]." KGs</td>
		            </tr>		 
		            <tr>
		              <td>Category</td>
			            <td>: ".$pcats[$i]."</td>
		            </tr>	
		            <tr>
		              <td>Type</td>
			          <td>: ".$ptypes[$i]."</td>
		            </tr>
		            <tr>
		              <td>Available</td>
			            <td>: ".$avails[$i]."</td>
		            </tr>		 
		            <tr>
		              <td colspan='2'><br/></td>
		            </tr>
                <tr>
		              <td colspan='2'>".$pdess[$i]."</td>
		            </tr>";
    if($type=='my'){  
    echo "
		            <tr>
		              <td>
    		            <a href='farmerproductedit.php?proid=$proid&edit=data'>
                    <button type='button' name='button' class='btn btn-dark'>Edit</button>
                    </a>
                    &nbsp; 
		   	          </td>
		              <td>
                  &nbsp;
    		            <a href='farmerviewfeedback.php?proid=$proid'>
                      <button type='button' name='button' class='btn btn-dark'>Feedback</button>
                    </a>  
		   	          </td>
                </tr>";
    }
    else{
    echo "
		            <tr>
		              <td>
    		            <a href='adminviewfarmer.php?fid=$farmer'>
                    <button type='button' name='button' class='btn btn-dark'>View Farmer
                    </button></a>
                    &nbsp; 
		   	          </td>
		              <td>
    		            &nbsp;
                    <a href='adminviewfeedback.php?proid=$proid'>
                      <button type='button' name='button' class='btn btn-dark'>Comments
                      </button>
                    </a>  
		   	          </td>
		            </tr>";
    }
    echo "
              </table>		 
	          </div>
            </center>
          </div>
	      </div>"; 
  }
  echo "
      </div>
    </div>
  </div>
</div>";

  if($a==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>Empty..!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
 require_once('backgroundfoot.php');
}
else
{
 header('Location: farmerlogin.php');
}
?>