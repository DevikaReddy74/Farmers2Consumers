<?php
session_start();
if(!empty($_SESSION['user']))
{
  if(!empty($_GET['proid']) && !empty($_GET['quant']) && !empty($_GET['oid']))
  {
    $userid=$_SESSION['user'];
    $proid=$_GET['proid'];
	$quant=$_GET['quant'];
	$oid=$_GET['oid'];
    $conn=new mysqli("localhost","root","","f2c");
    $stmt=$conn->prepare("DELETE FROM `orders` WHERE `Userid`=? AND `Productid`=? AND `Orderid`=?");
    $stmt->bind_param("sss",$userid,$proid,$oid);
    $stmt->execute();
    if($stmt->affected_rows>0)
    {
      echo "<script>window.alert('Order Deleted successfully');</script>";
    }
	else
    {
	  echo "<script>window.alert('Try again after sometime');</script>";
    }
    $conn=new mysqli("localhost","root","","f2c");
    $stmt=$conn->prepare("SELECT `Quantity` FROM `products` WHERE `Productid`=?");
    $stmt->bind_param("s",$proid);
    $stmt->execute();
    $stmt->bind_result($oriquant);      
    while($stmt->fetch())
    { 
      $updquant=$oriquant+$quant;
      $conn=new mysqli("localhost","root","","f2c");  
      $stmt=$conn->prepare("UPDATE `products` SET `Quantity`=? WHERE `Productid`=?");
      $stmt->bind_param("ss",$updquant,$proid);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
      }	
    }
    header('Location: userorder.php');
  }
}
else
{
  header('Location: userlogin.php');
}
?>