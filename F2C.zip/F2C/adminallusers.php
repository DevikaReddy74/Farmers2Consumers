<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
        <div class='card' style='width: auto;'>
	  			<div class='card-body'>
          <br/><h1 class="center"><u>User Details</u></h1><br/>

      <table border="1" align="center">
         <tr>
           <th>&nbsp;&nbsp;S.No&nbsp;&nbsp;</th>
           <th>&nbsp;Picture&nbsp;</th>
           <th>&nbsp;&nbsp;Name&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Gender&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;DOB&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Contact&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Email&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Address&nbsp;&nbsp;</th>
         </tr>
<?php
$data=0;
 $conn=new mysqli("localhost","root","","f2c");
 $sql="SELECT `userId`, `image`, `fullName`, `gender`, `dob`, `phoneNo`, `emailId`, `address`, `registerDate`, `updateOn` FROM `user` WHERE `password`!=?";
 $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$data);

 $stmt->execute();
 $stmt->bind_result($userid,$img,$fname,$gen,$dob,$phone,$mail,$addr,$regdate,$update);
 $a=0;
 $i=1;
 while($stmt->fetch())
 {
  $a=1;
  echo "  <tr>
          <td>&nbsp;&nbsp;".$i."&nbsp;&nbsp;</td>
          <td>&nbsp;<img src='".$img."' height='50%' width='80' alt='image'/>&nbsp;</td>
          <td>&nbsp;".$fname."&nbsp;</td>
          <td>&nbsp;".$gen."&nbsp;</td>
          <td>&nbsp;".$dob."&nbsp;</td>
          <td>&nbsp;".$phone."&nbsp;</td>
          <td>&nbsp;".$mail."&nbsp;</td>
          <td>".$addr."</td>
         </tr>";
  $i++;
 }
 if($a==0)
 {
  echo " <tr>
          <td colspan='7'>
            <h1 align='center'>Empty!<h1/>
          </td>
         </tr>";
 }
 if(!empty($_GET['uid']))
 {
  $user=$_GET['uid'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `user` WHERE `userId` = ? ");
  $stmt->bind_param("s",$user);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
   echo "
    <script>
      window.alert('User Deleted successfully');
    </script>";
    header('Location: adminallusers.php');

  }
  else
  {
   echo "<script>window.alert('User Not Deleted');</script>";
  }
 }
?>
      </table>
      <br/>
    </div>
    <div class="col-1">
    </div>
  </div>
  <br/>
  <br/>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>