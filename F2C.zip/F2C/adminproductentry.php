<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
	require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-4">
	  </div>
    <div class="col-4">	
	    <div class="card" style="width: auto;">
        <div class="card-body">
          <form action="" method="post" align="center" enctype="multipart/form-data" >
            <table align="center">
              <tr>
                <td colspan="2">
                  <u><h1>Product Entry </h1></u>
                </td>
              </tr>
              <tr>
                <td>Product Name</td>
                <td>
                  <input type="text" name="pname" maxlength="15" required/>
                </td>
              </tr>
              <tr>
                <td>Product View</td>
                <td>
                  <input type="file" name="pfile" required/>
                </td>
              </tr>
              <tr>
                <td>Price ₹ /KG</td>
                <td>
                  <input type="text" name="pprice" maxlength="5" required/>
                </td>
              </tr>
		          <tr>
		            <td>Available Quantity in KG's</td>
		            <td>
			            <input type="text" name="pquant" maxlength="10" required/>
			          </td>
		          </tr>
              <tr>
                <td>Description</td>
                <td>
                  <input type="text" name="pdes" maxlength="100" required/>
                </td>
              </tr>
              <tr>
                <td>Category</td>
                <td>
                  <select name="pcat">
                    <option>Vegetables</option>
                    <option>Fruits</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td>Type</td>
                <td>
                  <select name="ptype">
<?php
  require_once('producttypes.php');
?>
                  </select>
                </td>
              </tr>
              <tr>
                <td colspan="2">
                  <button type="submit" name="apes" class="btn btn-dark">Submit</button>
                </td>
              </tr>
            </table>
          </form>
	      </div>
	    </div>
    </div>
    <div class="col-4">
    </div>
  </div>
</div>
                            
<?php
  if(isset($_POST['apes']))
  {
	  $fname=$_FILES['pfile']['name'];
	  $ftemp=$_FILES['pfile']['tmp_name'];//default storage of images
	  $ferr=$_FILES['pfile']['error'];
	  if($ferr==0)
	  {
	  	date_default_timezone_set("Asia/Calcutta");//timezone
      $fname=date('YmdHis',time());// date and time
		  $fdest="./images/".$fname;
		  move_uploaded_file($ftemp,$fdest);//source, destination

      date_default_timezone_set("Asia/Calcutta");
      $date=date('d-m-Y H:i:s',time());

      $pname=$_POST['pname'];
      $pprice=$_POST['pprice'];
		  $pquant=$_POST['pquant'];
	    $pdes=$_POST['pdes'];
      $pcat=$_POST['pcat'];
		  $ptype=$_POST['ptype'];
      $conn=new mysqli("localhost","root","","f2c");
      $sql="INSERT INTO `product`(`farmerId`, `productName`, `image`, `price`, `quantity`, `description`, `category`, `type`, `createdOn`) VALUES (?,?,?,?,?,?,?,?,?)";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("sssssssss",$farmer,$pname,$fdest,$pprice,$pquant,$pdes,$pcat,$ptype,$date);
      $stmt->execute();
      if($stmt->affected_rows>0)
      {
			  echo "<script>window.alert('Item Added successfully');</script>";
      }
      else
      {
        echo "<script>window.alert('Item is not Added');</script>";
      }
	  }
	  else
	  {
		  echo "<script>window.alert('Error while uploading the file');</script>";
	  }
  }

  require_once('backgroundfoot.php');
}
else
{
	header('Location: adminlogin.php');
}
?>