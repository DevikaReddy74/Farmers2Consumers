<?php
session_start();
if(!empty($_SESSION['deliveryboy']))
{
  $boy=$_SESSION['deliveryboy'];
  $orderid=$_GET['orid'];
  require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>

<div class="alert">
  <div class="row">
    <div class="col-4">
	</div>
    <div class="col-4">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" enctype="multipart/form-data" align="center">
         <table align="center">
           <tr>
             <td colspan="2">
               <h1><u>Delivery Code</u></h1><br/>
             </td>
           </tr>
           <tr>
             <td colspan="2">
               <input type="text" name="code" placeholder="Delivery Code" required/>
             </td>
           </tr>
           <tr>
             <td><br/></td>
           </tr>
           <tr>
             <td>
               <a href="deliveryboyorders.php">
                  <button type='button' name='btn' class='btn btn-dark'>Back
                    </button>
                </a>
             </td>             
             <td>
                  <button type="submit" name="dbpds" class="btn btn-dark">Update</buttn>
             </td>
           </tr>
         </table>
         <br/>
       </form>
      </div>
	 </div>
	</div>
   <div class="col">
   </div>
  </div>
</div>

<?php
  if(isset($_POST['dbpds']))
  {
    $code=$_POST['code'];
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="SELECT `deliveryCode` FROM `orders` WHERE `orderId`=?";
    $stmt1=$conn->prepare($sql1);
    $stmt1->bind_param("s",$orderid);
    $stmt1->execute();
    $stmt1->bind_result($delcode);
    $count=0;
    while($stmt1->fetch())
    {
      $count=1;
    }
    if($count==1){
      if($delcode==$code){
        $pay="Paid";
        $status="Delivered";
        $sql2="UPDATE `orders` SET `payment`=?,`status`=? WHERE `orderId`=?";
        $stmt2=$conn->prepare($sql2);
        $stmt2->bind_param("sss",$pay,$status,$orderid);
        $stmt2->execute();
        if($stmt2->affected_rows==1)
        {
          echo "<script>window.alert('Updated successfully');</script>";
        }
        else
        { 
          echo "<script>window.alert('Not Updated. Something went Wrong');</script>";
        }
      }
      else{
        echo "<script>window.alert('Wrong Code, Try Again..!');</script>";
      }
    }
  }
  require_once('backgroundfoot.php');
}
else
{
  header('Location: deliveryboylogin.php');
}
?>