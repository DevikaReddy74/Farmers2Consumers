<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
  $orderid=$_GET['orid'];
?>


<div class="alert">
  <div class="row">
    <div class="col-4">
	</div>
    <div class="col-4">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" enctype="multipart/form-data" align="center">
         <table align="center">
           <tr>
             <td colspan="2">
               <h1><u>Delivery Code</u></h1><br/>
             </td>
           </tr>
           <tr>
             <td colspan="2">
               <input type="text" name="code" placeholder="Delivery Code" required/>
             </td>
           </tr>
           <tr>
             <td><br/></td>
           </tr>
           <tr>
             <td>
               <a href="adminallorders.php">
                  <input type="button" name="apds" value="Back"/>
                </a>
             </td>             
             <td>
               <input type="submit" name="apds" value="Update"/>
             </td>
           </tr>
         </table>
         <br/>
       </form>
      </div>
	 </div>
	</div>
   <div class="col">
   </div>
  </div>
</div>

<?php
  if(isset($_POST['apds']))
  {
    $code=$_POST['code'];
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="SELECT `deliveryCode` FROM `orders` WHERE `orderId`=?";
    $stmt1=$conn->prepare($sql1);
    $stmt1->bind_param("s",$orderid);
    $stmt1->execute();
    $stmt1->bind_result($delcode);
    $count=0;
    while($stmt1->fetch())
    {
      $count=1;
    }
    if($count==1){
      if($delcode==$code){
        $pay="Paid";
        $status="Delivered";
        $sql2="UPDATE `orders` SET `payment`=?,`status`=? WHERE `orderId`=?";
        $stmt2=$conn->prepare($sql2);
        $stmt2->bind_param("sss",$pay,$status,$orderid);
        $stmt2->execute();
        if($stmt2->affected_rows==1)
        {
          echo "<script>window.alert('Updated successfully');</script>";
        }
        else
        { 
          echo "<script>window.alert('Not Updated');</script>";
        }
      }
      else{
        echo "<script>window.alert('Wrong Code, Try Again..!');</script>";
      }
    }
  }

  
  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}
?>