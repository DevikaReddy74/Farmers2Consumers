<?php
session_start();
require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<br/>
<div class="alert">
  <div class="row">
    <div class="col">
	</div>
    <div class="col">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" enctype="multipart/form-data" align="center">
         <table align="center">
           <tr>
             <td colspan="2">
               <h1><u>Farmer Login</u></h1><br/>
             </td>
           </tr>
           <tr>
             <td>Username</td>
             <td>
               <input type="text" name="ul" required/>
             </td>
           </tr>
           <tr>
             <td>Password</td>
             <td>
               <input type="password" name="pl" required/>
             </td>
           </tr>
           <tr>
             <td></td>
             <td>
               Click here <a href="farmerforgotpassword.php">forgot Password?</a>
            </td>
           </tr>
           <tr>
             <td colspan="2" align="center">
               <button type="submit" name="fls" class="btn btn-dark">Login</button>
             </td>
           </tr>
           <tr>
             <td colspan="2">
               <h4>If Not Register? 
                 <a href="farmerregister.php">Register Here!</a>
               </h4>
             </td>
           </tr>
         </table>
         <br/>
         <h3>
           <a href="index.php">
           <button type="button" name="btn" class="btn btn-dark">Back</button>
          </a></h3>
       </form>
      </div>
	 </div>
	</div>
   <div class="col">
   </div>
  </div>
</div>

<?php
if(isset($_POST['fls']))
{ 
 if(!empty($_POST['ul']) && !empty($_POST['pl']))
 {
   $farmer=$_POST['ul'];
   $pwd=$_POST['pl'];
   $conn=new mysqli("localhost","root","","f2c");
   $sql="SELECT `farmerId`, `password` FROM `farmer` WHERE `userName`=?";
   $stmt=$conn->prepare($sql);
   $stmt->bind_param("s",$farmer);
   $stmt->execute();
   $stmt->bind_result($farmerid,$pass);
   $a=0;   
   while($stmt->fetch())
   {
      $a=1;
   }
   if($a==1)
   {
      $verify=password_verify($pwd,$pass);
      if($verify){
        $_SESSION['farmer']=$farmerid;
        header('Location: farmerhome.php');
        echo "<script>window.alert('Login successfully');</script>";
      }
      else{
        echo "<script>window.alert('Invalid Details');</script>";
      }
    }
    else
    {
      echo "<script>window.alert('User Does not exist');</script>";
    }
  }
  else
  {
     echo "<script>window.alert('Every field must be fill');</script>";
  }
}
require_once('backgroundfoot.php');
?>