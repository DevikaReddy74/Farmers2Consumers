<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

    <div class="dropdown-btn">Products
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
      <a href="adminproductentry.php">Add Product</a>
      <a href="adminhome.php">My Products</a>
      <a href="adminallproducts.php">All Products</a>
    </div>

    
    <div class="dropdown-btn">Orders
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
      <a href="adminorders.php">My Product Orders</a>
      <a href="adminallorders.php">All Orders</a>
      <a href="admindeliveredorders.php">Delivered Orders</a>
      <a href="admincancelededorders.php">Canceled Orders</a>
    </div>

    <div class="dropdown-btn">Delivery Boy
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
    <a href="adminadddeliveryboy.php">Add Delivery Boy</a>
    <a href="adminviewdeliveryboys.php">View Delivery Boy</a>
    </div>

    <a href="adminvieworderedproducts.php">All Ordered Products</a>

    <div class="dropdown-btn">Farmers
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
      <a href="adminacceptrejectfarmers.php">Requests</a>
      <a href="adminallfarmers.php">All Farmers</a>
    </div>

    <div class="dropdown-btn">Users
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
      <a href="adminacceptrejectusers.php">Requests</a>
      <a href="adminallusers.php">All Users</a>
    </div>

    <div class="dropdown-btn">Profile
      <i class="fa fa-caret-down"></i>
    </div>
    <div class="dropdown-container">
      <a href="adminprofile.php">Profile</a>
      <a href="adminchangepassword.php">Change Password</a>
    </div>

    <a href="adminlogout.php">Logout</a>
  </div>

<div class=" row title">
  <div class="col-1">
    <span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>
  </div>
  <div class="col-11">
    <h1 class="center">FARMERS2CONSUMERS</h1>
  </div>
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.display = "block";
}

function closeNav() {
  document.getElementById("mySidenav").style.display = "none";
}

/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}

</script>
<br/> 