<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>


<div class="alert">
  <div class="row">
    <div class="col">
	</div>
    <div class="col">	
	 <div class="card" style="width: auto;">
      <div class="card-body">
       <form action="" method="post" enctype="multipart/form-data" align="center">
         <table align="center">
           <tr>
             <td colspan="2">
               <h1><u>Change Password</u></h1><br/>
             </td>
           </tr>
           <tr>
             <td>
               <input type="password" name="opwd" placeholder="Old Password" required/>
             </td>
           </tr>
             <td>
               <input type="password" name="npwd" placeholder="New Password" required/>
             </td>
           </tr>
           </tr>
             <td><br/></td>
           </tr>
           <tr>
             <td align="center">
               <button type="submit" name="acps" class="btn btn-dark">Update</button>
             </td>
           </tr>
         </table>
         <br/>
       </form>
      </div>
	 </div>
	</div>
   <div class="col">
   </div>
  </div>
</div>

<?php
  if(isset($_POST['acps']))
  {
    $opwd=$_POST['opwd'];
    $npwd=$_POST['npwd'];  
    $conn=new mysqli("localhost","root","","f2c");
    $sql1="SELECT `password` FROM `admin` WHERE `farmerId`=?";
    $stmt1=$conn->prepare($sql1);
    $stmt1->bind_param("s",$farmer);
    $stmt1->execute();
    $stmt1->bind_result($pass);
    $a=0;
    while($stmt1->fetch())
    {
      $a=1;
    }
    if($a==1)
    {
      $verify=password_verify($opwd,$pass);
      if($verify){
        $pass=password_hash($npwd,PASSWORD_DEFAULT);
        $sql2="UPDATE `admin` SET `password`=? WHERE `farmerId`=?";
        $stmt2=$conn->prepare($sql2);
        $stmt2->bind_param("ss",$pass,$farmer);
        $stmt2->execute();
        if($stmt2->affected_rows==1)
        {
          echo "<script>window.alert('Password Updated successfully');</script>";
        }
        else
        { 
          echo "<script>window.alert('Not Updated');</script>";
        }
      }
      else{
        echo "<script>window.alert('Wrong Password');</script>";
      }
    }
  }

  
  require_once('backgroundfoot.php');
}
else
{
  header('Location: adminlogin.php');
}
?>