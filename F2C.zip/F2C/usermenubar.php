<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="userhome.php">Home</a>
    <a href="usercart.php">My Cart</a>
    <a href="userwishlist.php">My Wishlist</a>
    <a href="userorders.php">My Orders</a>
    <a href="usercanceledorders.php">Canceled Orders</a>
    <a href="userdeliveredorders.php">Delivered Orders</a>
    <a href="userprofile.php">Profile</a>
    <a href="userchangepassword.php">Change Password</a>
    <a href="userlogout.php">Logout</a>
  </div>

<div class=" row title">
  <div class="col-1">
    <span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>
  </div>
  <div class="col-11">
    <h1 class="center">FARMERS2CONSUMERS</h1>
  </div>
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.display = "block";
}

function closeNav() {
  document.getElementById("mySidenav").style.display = "none";
}
</script>
<br/>