<?php
  require_once('backgroundhead.php');
?>
<div class="row title center">
  <div class="col">
    <h1>FARMERS2CONSUMERS</h1>
  </div>     
</div>
<br/>
<div class="alert"> 
  <div class="row">
    <div class="col-2">
    </div>

    <div class="col-4 center">
      <div class='card' style='width: auto;'>
	  		<div class='card-body'>
          <a href="farmerlogin.php">
	          <img src="images/farmer.png" alt="farmer" height="300" width="300"/><br/>
		        <h1>FARMER LOGIN</h1>
          </a>    
        </div>
      </div>
    </div>
          
    <div class="col-4 center">
      <div class='card' style='width: auto;'>
	  		<div class='card-body'>
          <a href="userlogin.php">
	          <img src="images/user.png" alt="user" height="300" width="300"/><br/>
		        <h1>USER LOGIN</h1>
          </a>
        </div>
      </div>    
    </div>

    <div class="col-2">
    </div>
  </div>
<?php
require_once('backgroundfoot.php');
?>