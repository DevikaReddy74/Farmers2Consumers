<?php
session_start();
if(!empty($_SESSION['admin']))
{
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>
<div class="alert">
  <div class="row">
    <div class="col-2">
    </div>
    <div class="col-8">
      <div class='card' style='width: auto;'>
        <br/><h1 class="center"><u>All Products Ordered By Users</u></h1>
				<div class='card-body'>
        <table border="1" class="center" align="center">
         <tr>
           <th>&nbsp;&nbsp;S.No&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Farmer Id&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Product Id&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Product&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Quantity KGs&nbsp;&nbsp;</th>
           <th>&nbsp;&nbsp;Deliver On&nbsp;&nbsp;</th>
          </tr>
<?php

    $or="Ordered";
    date_default_timezone_set("Asia/Calcutta");
    $date=date('d-m-Y',time());
    $conn=new mysqli("localhost","root","","f2c");
    $sql="SELECT  p.`farmerId`, oi.`productId`, p.`image`, SUM(oi.`quantity`), o.`deliverOn` FROM `orders` o JOIN `orderitems` oi ON o.`orderId`=oi.`orderId` JOIN `product` p ON p.`productId`=oi.`productId` WHERE o.`status`=? AND o.`deliverOn`=? GROUP BY p.`farmerId`, oi.`productId`, p.`image`, o.`deliverOn` ORDER BY p.`farmerId`";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("ss",$or,$date);
    $stmt->execute();
    $stmt->bind_result($fid,$pid,$img,$quant,$delon);
    $a=0;
    while($stmt->fetch())
    {
      $a++;
      echo "  <tr>
          <td>&nbsp;&nbsp;".$a."&nbsp;&nbsp;</td>
          <td>
            &nbsp;&nbsp;<a href='adminviewfarmer.php?fid=$fid'>".$fid."</a>&nbsp;&nbsp;
          </td>
          <td>
						&nbsp;&nbsp;<a href='adminviewproduct.php?pid=$pid'>".$pid."</a>&nbsp;&nbsp;
          </td>
          <td>&nbsp;<img src='".$img."' height='50%' width='80' alt='image'/>&nbsp;</td>
          <td>&nbsp;&nbsp;".$quant."&nbsp;&nbsp;</td>
          <td>&nbsp;&nbsp;".$delon."&nbsp;&nbsp;</td>
         </tr>";
      
    }
    if($a==0)
    {
      echo " <tr>
          <td colspan='6'>
            <h1 align='center'>Empty!<h1/>
          </td>
         </tr>";
    }
    else{
      echo "<center> 
          <button onClick='window.print()' class='btn btn-dark'>Print</button>
          </center><br/>";
    }
    echo "</table>";
?>
    <br/>
    </div>
    <div class="col-2">
    </div>
  </div>
<br/>
<br/>

</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>