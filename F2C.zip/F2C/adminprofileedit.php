<?php
session_start();
if(!empty($_SESSION['admin']))
{
  $farmer=$_SESSION['id'];
  $id=$_GET['edit'];
  require_once('backgroundhead.php');
  require_once('adminmenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4">
	
<?php
if($id=="img")
{
?>
      <div class="card" style="width: auto;">
        <h1 class="center"><u>Profile</u></h1><br/>
        <form action="" method="post" align="center" enctype="multipart/form-data" >
          <table border="0" align="center">
            <tr>
              <td>Photo</td>
              <td>
                <input type="file" name="pfile" required/>
              </td>
            </tr>
            <tr>
              <td colspan="2"><br/></td>
            </tr>
            <tr>
              <td>
                <a href="adminprofile.php">
                  <button type="button" class='btn btn-dark'>Back</button>
                </a>
              </td>
              <td>
                <button type="submit" name="apies" class='btn btn-dark'>Update</button>
              </td>
            </tr>
          </table>
        </form>
        <br/>
      </div>

<?php
  if(isset($_POST['apies']))
  {
	  $fname=$_FILES['pfile']['name'];
	  $ftemp=$_FILES['pfile']['tmp_name'];//default storage of images
	  $ferr=$_FILES['pfile']['error'];
	  if($ferr==0)
	  {
	  	date_default_timezone_set("Asia/Calcutta");//timezone
      $fname=date('dmYHis',time());// date and time
		  $fdest="./images/".$fname;
		  move_uploaded_file($ftemp,$fdest);//source, destination
    
      $conn=new mysqli("localhost","root","","f2c");
      $sql="UPDATE `admin` SET `image`=? WHERE `farmerId`=?";
      $stmt=$conn->prepare($sql);
      $stmt->bind_param("ss",$fdest,$farmer);
      $stmt->execute();
      if($stmt->affected_rows==1)
      {
		    echo "<script>window.alert('Updated successfully');</script>";
      }
      else
      {
		    echo "<script>window.alert('Not Updated');</script>";
      }
    }
	  else
	  {
		  echo "<script>window.alert('Error while uploading the file');</script>";
	  }
  }  
}

if($id=="data")
{
  $conn=new mysqli("localhost","root","","f2c");
  $sql="SELECT `userName`, `fullName`, `gender`, `dob`, `phoneNo` FROM `admin` WHERE `farmerId`=?";
  $stmt=$conn->prepare($sql);
  $stmt->bind_param("s",$farmer);
  $stmt->execute();
  $stmt->bind_result($uname,$fname,$gen,$dob,$phno);
  $a=0;
  while($stmt->fetch())
  {
    $a++;
  }
  if($a==1)
  {
?>
      <div class="card" style="width: auto;">
        <h1 class="center"><u>Profile</u></h1><br/>
        <form action="" method="post">
          <table border="0" align="center">
            <tr>
              <td>Full Name</td>
              <td>
                <input type="text" name="fn" value="<?php echo $fname; ?>" required/>
              </td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>
                <input type="radio" name="ge" value="Male" required/>Male
                <input type="radio" name="ge" value="Female" required/>Female
              </td>
            </tr>
            <tr>
              <td>DOB</td>
              <td>
                <input type="date" name="dob" value="<?php echo $phno; ?>" required/>
              </td>
            </tr>
            <tr>
              <td>Phone No</td>
              <td>
                <input type="text" name="ph" maxlength="10" value="<?php echo $phno; ?>" required/>
              </td>
            </tr>
            <tr>
              <td>User Name</td>
              <td>
                <input type="text" name="ur" maxlength="15" value="<?php echo $uname; ?>" readonly/>
              </td>
            </tr>
	          <tr>
	            <td colspan='2'><br/></td>
	          </tr>
            <tr>
              <td>
                <a href="adminprofile.php">
                  <button type="button" class="btn btn-dark">Back</button>
                </a>
              </td>
              <td>
                <button type="submit" name="apes" class="btn btn-dark">Update</button>
              </td>
            </tr>
          </table>
          <br/>
        </form>
	    </div>
<?php
  }

  if(isset($_POST['apes']))
  {
    date_default_timezone_set("Asia/Calcutta");
    $date=date('d-m-Y H:i:s',time());

    $uename=$_POST['fn'];
    $ugen=$_POST['ge'];
    $udob=$_POST['dob'];
    $uphno=$_POST['ph'];
    $uuname=$_POST['ur'];
    $conn=new mysqli("localhost","root","","f2c");
    $sql="UPDATE `admin` SET `userName`=?,`fullName`=?,`gender`=?,`dob`=?,`phoneNo`=?,`updateOn`=? WHERE `farmerId`=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("sssssss",$uuname,$uename,$ugen,$udob,$uphno,$date,$farmer);
    $stmt->execute();
    if($stmt->affected_rows==1)
    {
		  echo "<script>window.alert('Updated successfully');</script>";
    }
    else
    {
		  echo "<script>window.alert('Not Updated');</script>";
    }
  }  
}
?>

   
    </div>
    <div class="col-4">
    </div>
  </div>
</div>

<?php   
 require_once('backgroundfoot.php');
}
else
{
 header('Location: adminlogin.php');
}
?>
