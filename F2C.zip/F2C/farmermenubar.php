<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="farmerhome.php">Home</a>
    <a href="farmerproductentry.php">Add Product</a>
    <a href="farmerorders.php">Orders</a>
    <a href="farmerdeliveredorders.php">Delivered Orders</a>
    <a href="farmercanceledorders.php">Canceled Orders</a>
    <a href="farmerprofile.php">Profile</a>
    <a href="farmerchangepassword.php">Change Password</a>
    <a href="farmerlogout.php">Logout</a>
  </div>

<div class=" row title">
  <div class="col-1">
    <span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>
  </div>
  <div class="col-11">
    <h1 class="center">FARMERS2CONSUMERS</h1>
  </div>
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.display = "block";
}

function closeNav() {
  document.getElementById("mySidenav").style.display = "none";
}
</script>
<br/> 