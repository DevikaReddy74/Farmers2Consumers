<?php
session_start();
if(!empty($_SESSION['farmer']))
{
  $farmerid=$_SESSION['farmer'];
  require_once('backgroundhead.php');
  require_once('farmermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-1">
    </div>
    <div class="col-10">
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <h1 class="center"><u>Delivered Products</u></h1><br/>
          <table border='1' align='center' class='center'>
            <tr>
              <th>S.No</th>
              <th>Product ID</th>
              <th>&nbsp;&nbsp;&nbsp;Name&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Product&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Quantity&nbsp;&nbsp;&nbsp;</th>
              <th>&nbsp;₹ Cost /KG&nbsp;</th>
              <th>&nbsp;&nbsp;&nbsp;Total ₹&nbsp;&nbsp;&nbsp;</th>
              <th>Order On</th>
              <th>Deliver On</th>

            </tr>
<?php
  $status="Delivered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT oi.`productId`, o.`userId`, p.`productName`, p.`image`, oi.`quantity`, oi.`price`, oi.`total`, o.`orderOn`, o.`deliverOn` FROM `orderitems` oi JOIN `product` p ON oi.`productId`=p.`productId` JOIN `orders` o ON oi.`orderId`=o.`orderId` WHERE p.`farmerId`=? AND o.`status`=? ORDER BY oi.`orderId` DESC";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$farmerid,$status);
  $stmt1->execute();
  $stmt1->bind_result($pid,$usrid,$pname,$img,$quant,$price,$total,$oon,$delon);
  $count=0;
  while($stmt1->fetch())
  {
    $count++;
    echo "
            <tr>
		          <td>".$count."</td>
		          <td>".$pid."</td>
		          <td>".$pname."</td>
		          <td><img src='".$img."' width='50' height='50'/></td>
		          <td>".$quant."</td>
		          <td>".$price."</td>
		          <td>₹ ".$total."</td>
		          <td>&nbsp;&nbsp;".$oon."&nbsp;&nbsp;</td>
		          <td>&nbsp;&nbsp;".$delon."&nbsp;&nbsp;</td>
		        </tr>";
  }
  if($count==0){
    echo "
            <tr>
		          <td colspan='8'><h1>Empty...!</h1></td>
		        </tr>";
  }
?>
          </table>
          <br/>
        </div>
      </div>
    </div>
    <div class="col-1">
    </div>
	</div>
</div>

<?php
  require_once('backgroundfoot.php');
}
else
{
  header('Location: farmerlogin.php');
}
?>