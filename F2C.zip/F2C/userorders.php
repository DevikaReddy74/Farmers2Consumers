<?php
session_start();
if(!empty($_SESSION['user']))
{
  $userid=$_SESSION['user'];
  require_once('backgroundhead.php');
  require_once('usermenubar.php');
?>

<div class="alert">
  <div class="row">
    <div class="col-12">
      <h1 class="center white"><u>Your Orders</u></h1><br/>
      <div class='row row-cols-4'>
         
<?php    
  $status="Ordered";
  $conn=new mysqli("localhost","root","","f2c");
  $sql1="SELECT `orderId`, `orderTotal`, `deliveryCharge`, `totalPay`, `payment`, `orderOn`, `deliverOn`, `deliveryAddress` FROM `orders` WHERE `userId`=? AND `status`=? ORDER BY `orderOn` DESC";
  $stmt1=$conn->prepare($sql1);
  $stmt1->bind_param("ss",$userid,$status);
  $stmt1->execute();
  $stmt1->bind_result($id,$total,$delcharg,$totalpay,$pay,$oon,$delon,$deladdr);
  $c=0; 
  $empty=0;
  $oids=array(); 
  $ototal=array(); 
  $odelcharg=array(); 
  $ototalpay=array(); 
  $opay=array(); 
  $ooon=array(); 
  $odelon=array(); 
  $odeladdr=array(); 
  while($stmt1->fetch())
  {   
    $empty=1;
    $oids[$c]=$id;
    $ototal[$c]=$total;
    $odelcharg[$c]=$delcharg; 
    $ototalpay[$c]=$totalpay; 
    $opay[$c]=$pay; 
    $ooon[$c]=$oon;
    $odelon[$c]=$delon; 
    $odeladdr[$c]=$deladdr; 
    $c+=1;
  }
  for($i=0;$i<$c;$i++){
    $orid=$oids[$i];
    $cost=$ototalpay[$i];
    $payment=$opay[$i];
    $deladdrs=$odeladdr[$i];
    $sql2="SELECT oi.`quantity`, oi.`price`, oi.`total`, oi.`productId`, p.`productName`, p.`image` FROM `orderitems` oi JOIN `product` p ON p.`productId`=oi.`productId` WHERE `orderId`=? ";
    $stmt2=$conn->prepare($sql2);
    $stmt2->bind_param("s",$orid);
    $stmt2->execute();
    $stmt2->bind_result($oiquant,$oiprice,$oitotal,$oipid,$oiproname,$oiimag);
    $a=0; 
    $oid=array(); 
    echo "        
        <div class='col'>
          <div class='card' style='width: auto;'>
            <div class='card-body'>
              <table class='center'>
		            <tr>
			            <th>Product</th>
			            <th>Cost /KG</th>
                  <th>&nbsp;*&nbsp;</th>
                  <th>Quantity</th>
                  <th>&nbsp;=&nbsp;</th>
                  <th>Toatal</th>
			          </tr>
    ";    
    while($stmt2->fetch())
    {
      echo "             
		            <tr>
		        	    <td>
                    <a href='userviewitem.php?proid=$oipid'>
                      <img src='".$oiimag."' height='auto' width='50'/>
                      <br/>".$oiproname."
                    </a> 
                  </td>
                  <td>".$oiprice."</td>
                  <td>*</td>
                  <td>".$oiquant."</td>
                  <td>=</td>
                  <td>".$oitotal."</td>
			          </tr>
      ";
    }
    echo"	
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
                <tr>
                  <th colspan='5'>Total</th>
                  <th>".$ototal[$i]."</th>
                </tr>                
                <tr>
                  <th colspan='4'>Delivery Charge</th>
                  <th>+</th>
                  <th>".$odelcharg[$i]."</th>
                </tr>
                <tr>
                  <th colspan='4'></th>
                  <th colspan='2'>________</th>
                </tr>                
                <tr>
                  <th colspan='5'>Total Amount to Pay</th>
                  <th>".$ototalpay[$i]."</th>
                </tr>
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
                <tr>
                  <th colspan='2'>Order On</th>
                  <th colspan='4'>".$ooon[$i]."</th>
                </tr>
                <tr>
                  <th colspan='2'>Deliver On</th>
                  <th colspan='4'>".$odelon[$i]."</th>
                </tr>
                <tr>
                  <td colspan='6'><br/></td>
                </tr>
                <tr>
                  <th colspan='2'>Payment</th>
                  <th colspan='4'>".$opay[$i]."</th>
                </tr>  
                <tr>
                  <td colspan='6'>
                    ---------------------------------------------------
                  </td>
                </tr>
                <tr>
                  <td colspan='6'>
			              <a href='userorderdeladdr.php?deladdr=$deladdrs'>
                      <button type='button' class='btn btn-dark'>View Delivery Address</button>
                    </a>
                  </td>
                </tr>
              </table>
              <br/>";
    date_default_timezone_set("Asia/Calcutta");
    $date=date("d-m-Y",strtotime('tomorrow'));

    if($payment=="Not Paid"){ 
        if($odelon[$i]==$date){
          echo "
              <table align='center'> 
                <tr>
                  <td>
			              <a href='userorderdeladdr.php?oid=$orid'>
                      <button type='button' class='btn btn-dark'>Change Delivery Address</button>
                    </a>
			            </td>
		            </tr>                                   
              </table> ";      
        }
      echo "<br/>
              <table align='center'> 
                <tr>
			            <td>
			              <a href='userorderpay.php?oid=$orid&ttl=$cost'>
                      <button type='button' class='btn btn-dark'>Pay Now</button>
                    </a>
			            </td>
                  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
                  <td>
			              <a href='userordercancel.php?oid=$orid'>
                      <button type='button' class='btn btn-dark'>Cancel Order</button>
                    </a>
			            </td>
		            </tr>                                   
              </table> ";

      }  
      echo "                     
            </div>
          </div>
        </div>";
  } 
?>
      </div> 
    </div>
  </div>
</div>

<?php
  if($empty==0)
  {  
    echo "
  <div class='row'>
    <div class='col-4'>
    </div>    
    <div class='col-4'>
      <div class='card' style='width: auto;'>
        <div class='card-body'>
          <br/>
          <br/>
          <h1 class='center'>EMPTY...!</h1>
          <br/>
          <br/>
        </div>
      </div>  
    </div>  
    <div class='col-4'>
    </div>
  </div>";
  }
  require_once('backgroundfoot.php');
}
else
{
  header('Location: userlogin.php');
}

?>  