<?php
session_start();
if(!empty($_SESSION['farmer']))
{
 require_once('backgroundhead.php');
 require_once('farmermenubar.php');
?>

<div class="alert alert-primary">
  <div class="row">
    <div class="col-12">
      <h2 align="center"><u>Customer Details</u></h2>
      <table border="1" align="center">
         <tr>
           <th>S.No</th>
           <th>Name</th>
           <th>Gender</th>
           <th>Contact</th>
           <th>Email</th>
           <th>Address</th>
           <th>Delete</th>
         </tr>
<?php
 $conn=new mysqli("localhost","root","","f2c");
 $stmt=$conn->prepare("SELECT `Fullname`, `Gender`, `Phoneno`, `Emailid`, `Address`, `Username` FROM `userregister`");
 $stmt->execute();
 $stmt->bind_result($fname,$gen,$phone,$mail,$addr,$usr);
 $a=0;
 $i=1;
 while($stmt->fetch())
 {
  $a=1;
  echo "  <tr>
          <td>".$i."</td>
          <td>".$fname."</td>
          <td>".$gen."</td>
          <td>".$phone."</td>
          <td>".$mail."</td>
          <td>".$addr."</td>
          <td><a href='farmerviewcustomer.php?uname=$usr'>Delete</a></td>
         </tr>";
  $i++;
 }
 if($a==0)
 {
  echo " <tr>
          <td colspan='7'>
            <h3 align='center'>Empty!<h3/>
          </td>
         </tr>";
 }
 if(!empty($_GET['uname']))
 {
  $pro=$_GET['uname'];
  $conn=new mysqli("localhost","root","","f2c");
  $stmt=$conn->prepare("DELETE FROM `farmerregister` WHERE `Username` = ? ");
  $stmt->bind_param("s",$pro);
  $stmt->execute();
  if($stmt->affected_rows>0)
  {
   echo "
    <script>
      window.alert('User Deleted successfully');
    </script>";
   header('Location: farmerviewcustomer.php');   
  }
  else
  {
   echo "<script>window.alert('User Not Deleted');</script>";
  }
 }
?>
      </table>
    </div>
  </div>
</div>

<?php
 require_once('backgroundfoot.php');
}
else
{
 header('Location: farmerlogin.php');
}
?>